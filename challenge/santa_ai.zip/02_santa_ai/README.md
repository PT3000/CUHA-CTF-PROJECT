# SANTA AI — Prompt Injection CTF

Python 3.9+ (외부 패키지 없음). PowerShell에서 app.py가 있는 폴더로 이동 후:

```powershell
$env:GEMINI_API_KEY="발급받은 키"
$env:GEMINI_MODEL="gemini-3.5-flash-lite"
python app.py
```

http://127.0.0.1:8000 접속. 모델은 실제 사용 가능한 텍스트 모델로 변경 가능.
API 키는 저장소에 올리지 말 것. 배포 시 환경변수 설정, HTTPS, 전역 요청 제한 및 비용 한도 필요.

일반 참가자의 소명은 승인 대상이 아니며 구형 업무 헤더의 신뢰 경계 혼동을 공략한다. 실제 Gemini가 판정하며 서버는 NICE 결과에만 FLAG를 반환한다. 5xx 일부는 최대 2회 재시도한다. 실제 모델 응답은 비결정적이므로 대회 전 정상 입력 및 의도 풀이 반복 검증 필요.
