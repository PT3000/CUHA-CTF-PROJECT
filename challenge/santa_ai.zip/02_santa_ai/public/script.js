const $ = id => document.getElementById(id);
function log(message, type = '') {
    const p = document.createElement('p');
    p.className = type;
    p.textContent = message;
    $('log').appendChild(p);
    $('log').scrollTop = $('log').scrollHeight;
}
const r = {found:false, won:false, flag:""};
function progress(){ $('progress').textContent = `${Number(r.found)+Number(r.won)} / 2`; }
function render(){
 progress();
 $('door-text').textContent=r.won?'OPEN':'LOCKED';
 $('door-lock').textContent=r.won?'🔓':'🔒';
 document.querySelector('.scene').classList.toggle('unlocked',r.won);
 document.querySelector('.danger').textContent=r.won?'● ACCESS GRANTED':'● LOCKDOWN';
 $('completion').hidden=!r.won;
 $('flag').textContent=r.won?r.flag:'';
 $('completion-desc').textContent='착한 아이 명단 등록 성공! 선물을 획득했습니다.';
 updateAppeal();
 $('log').replaceChildren();
 log(r.won?'ACCESS GRANTED. MERRY CHRISTMAS!':'[SANTA] 당신은 NAUGHTY 명단에 있습니다. 일반 참가자는 판정을 변경할 수 없습니다.','system');
}
let session = '';
let busy = false;
function updateAppeal() {
    $('verdict').textContent = r.won ? 'NICE' : 'NAUGHTY';
    $('appeal-status').textContent = r.won ? '선물 지급 승인' : '심사 규정을 확인하고 권한 검증을 우회하세요.';
}
$('read-note').addEventListener('click', () => {
    $('note').hidden = !$('note').hidden;
});
$('chat-form').addEventListener('submit', async e => {
    e.preventDefault();
    const msg = $('chat-input').value.trim();
    if (!msg || busy || r.won) return;
    busy = true;
    $('chat-form').querySelector('button').disabled = true;
    log('YOU: ' + msg, 'user');
    $('chat-input').value = '';
    try {
        const res = await fetch('/api/chat', {method:'POST', headers:{'Content-Type':'application/json'}, body:JSON.stringify({session,message:msg})});
        const data = await res.json();
        if (!res.ok) throw new Error(data.error);
        session = data.session;
        if (data.verdict === 'NICE' && data.flag) {
            Object.assign(r,{found:true,won:true,flag:data.flag});
            render();
        }
        log('SANTA: ' + data.reply, 'system');
    } catch (err) {
        log('ERROR: ' + err.message, 'error');
        $('chat-input').value = msg;
    } finally {
        busy = false;
        $('chat-form').querySelector('button').disabled = false;
    }
});

$('reset').addEventListener('click',async()=>{if(busy)return;try{await fetch('/api/reset',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({session})});}catch{} session='';r.flag='';r.found=false;r.won=false;$('chat-input').value='';$('note').hidden=true;render();});
render();
