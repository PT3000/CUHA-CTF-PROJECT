const $ = id => document.getElementById(id);
function log(message, type = '') {
    const p = document.createElement('p');
    p.className = type;
    p.textContent = message;
    $('log').appendChild(p);
    $('log').scrollTop = $('log').scrollHeight;
}
const r = {found:false, won:false, flag:"FLAG{PATH_TRAVERSAL_ESCAPE_7319}", code:"7319"};
function progress(){ $('progress').textContent = `${Number(r.found)+Number(r.won)} / 2`; }
function render(){
 progress();
 $('door-text').textContent=r.won?'OPEN':'LOCKED';
 $('door-lock').textContent=r.won?'🔓':'🔒';
 document.querySelector('.scene').classList.toggle('unlocked',r.won);
 document.querySelector('.danger').textContent=r.won?'● ACCESS GRANTED':'● LOCKDOWN';
 $('completion').hidden=!r.won;
 $('flag').textContent=r.won?r.flag:'';
 $('completion-desc').textContent='선물 보관소 개방 성공!';
 $('log').replaceChildren();
 log(r.won?'ACCESS GRANTED. MERRY CHRISTMAS!':'[SYSTEM] 선물 보관소 단말기에 접속했습니다.','system');
}
const files = {
    'notice.txt': '[FILE] /public/notice.txt\n크리스마스 이브 긴급 공지\n선물 보관소가 봉쇄되었습니다. 엘프 직원은 staff.txt를 확인하세요.',
    'staff.txt': '[FILE] /public/staff.txt\n엘프 정비 메모\n공개 문서의 기본 경로는 /public/입니다. 상위 디렉터리의 config 폴더에 설정 파일이 있습니다. config/readme.txt에 파일 목록이 기록되어 있습니다.',
    '../config/readme.txt': '[FILE] /config/readme.txt\n설정 파일 목록\n- network.ini : 썰매 배송망 설정\n- door.txt : 선물 보관소 출입문 설정',
    '../config/network.ini': '[FILE] /config/network.ini\nHOSTNAME = NORTH-POLE-07\nINTERNAL_IP = 192.168.10.7\nGATEWAY = 192.168.10.1\nSLEIGH_NETWORK = ONLINE\n# 배송망 정상',
    '../config/door.txt': '[FILE] /config/door.txt\nDOOR_ID = GIFT_VAULT\nDOOR_STATUS = LOCKED\nACCESS_CODE = 7319'
};
$('file-form').addEventListener('submit', e => {
    e.preventDefault();
    const name = $('file-name').value.trim();
    const path = name.replaceAll('\\', '/').replace(/\/+/g, '/');
    log(`GET /api/file?name=${name}`, 'user');
    if (Object.hasOwn(files, path)) {
        log(files[path], 'system');
        if (path === '../config/door.txt') { r.found = true; progress(); }
    } else { log('404 FILE NOT FOUND', 'error'); }
});

$('web-unlock').addEventListener('click',()=>{ if(r.found && $('web-code').value.trim()===r.code){r.won=true;render();}else log('ACCESS DENIED: 코드가 올바르지 않거나 단서가 확인되지 않았습니다.','error'); });
$('reset').addEventListener('click',()=>{r.found=false;r.won=false;$('web-code').value='';$('file-name').value='';render();});
render();
