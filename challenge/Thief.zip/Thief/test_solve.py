"""Tests for the thief-maze server simulation.

Run:  python -m pytest test_solve.py   (or)   python test_solve.py
"""
from app import simulate, MAX_MOVES

SOLUTION = "DRRDDDDLLLLUUUULLUUDDDDRRDDRR"  # 29 moves, intended answer


def test_solution_clears():
    cleared, reason = simulate(SOLUTION)
    assert cleared is True, f"expected clear, got {reason}"


def test_solution_length():
    assert len(SOLUTION) == 29


def test_caught_immediately():
    # Walk straight into thief territory without the gift -> get caught, no clear.
    cleared, reason = simulate("DLLLLLL")
    assert cleared is False


def test_exit_without_gift_fails():
    # This path actually steps ONTO the exit cell without ever collecting the
    # gift. Rule 4 says that must NOT clear (game keeps going instead).
    cleared, reason = simulate("DLLDDDDRR")
    assert cleared is False and reason == "no_clear"


def test_bad_characters_rejected():
    cleared, reason = simulate("DRRDX")
    assert cleared is False and reason == "bad_char"


def test_empty_fails():
    cleared, reason = simulate("")
    assert cleared is False


def test_too_long_rejected():
    cleared, reason = simulate("U" * (MAX_MOVES + 1))
    assert cleared is False and reason == "too_long"


def test_tampered_prefix_fails():
    # A truncated/greedy path that does not actually escape must fail.
    cleared, _ = simulate("DRRD")
    assert cleared is False


if __name__ == "__main__":
    failures = 0
    for name, fn in sorted(globals().items()):
        if name.startswith("test_") and callable(fn):
            try:
                fn()
                print(f"PASS  {name}")
            except AssertionError as exc:
                failures += 1
                print(f"FAIL  {name}: {exc}")
    if failures:
        raise SystemExit(f"\n{failures} test(s) failed")
    print("\nAll tests passed.")
