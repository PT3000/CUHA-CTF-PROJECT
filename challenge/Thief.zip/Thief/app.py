import os
from collections import deque

from flask import Flask, jsonify, render_template, request

app = Flask(__name__)

# ---------------------------------------------------------------------------
# Game definition (MUST stay identical to static/game.js)
# ---------------------------------------------------------------------------
MAZE = [
    "###########",
    "#..G#.....#",
    "###.#.#P###",
    "#T........#",
    "#.#.#.###.#",
    "#.T...#...#",
    "#.###.#.#.#",
    "#......E..#",
    "#.#.#.#.#.#",
    "#.........#",
    "###########",
]

ROWS = len(MAZE)
COLS = len(MAZE[0])

START_PLAYER = (2, 7)
START_THIEF1 = (3, 1)
START_THIEF2 = (5, 2)
GIFT = (1, 3)
EXIT = (7, 7)

# Direction order is part of the rules: U, D, L, R.
ORDER = ["U", "D", "L", "R"]
DELTA = {"U": (-1, 0), "D": (1, 0), "L": (0, -1), "R": (0, 1)}

MAX_MOVES = 500


def is_wall(r, c):
    if r < 0 or r >= ROWS or c < 0 or c >= COLS:
        return True
    return MAZE[r][c] == "#"


def bfs(src):
    """Distance from src to every reachable floor cell (walls block, thieves do not)."""
    dist = [[-1] * COLS for _ in range(ROWS)]
    sr, sc = src
    dist[sr][sc] = 0
    q = deque([src])
    while q:
        r, c = q.popleft()
        for d in ORDER:
            dr, dc = DELTA[d]
            nr, nc = r + dr, c + dc
            if is_wall(nr, nc):
                continue
            if dist[nr][nc] == -1:
                dist[nr][nc] = dist[r][c] + 1
                q.append((nr, nc))
    return dist


def move_thief(thief, other, dist):
    """Move one step toward the player following the U/D/L/R rule, or stay put."""
    cr, cc = thief
    cur = dist[cr][cc]
    for d in ORDER:
        dr, dc = DELTA[d]
        nr, nc = cr + dr, cc + dc
        if is_wall(nr, nc):
            continue
        if (nr, nc) == other:
            continue
        nd = dist[nr][nc]
        if nd != -1 and nd < cur:
            return (nr, nc)
    return thief


def simulate(moves):
    """Replay a move string. Returns (cleared: bool, reason: str)."""
    if len(moves) > MAX_MOVES:
        return False, "too_long"
    for ch in moves:
        if ch not in DELTA:
            return False, "bad_char"

    player = START_PLAYER
    t1 = START_THIEF1
    t2 = START_THIEF2
    has_gift = False

    for ch in moves:
        dr, dc = DELTA[ch]
        nr, nc = player[0] + dr, player[1] + dc

        # Rule 1: walls / thieves / staying put are illegal -> input ignored.
        if is_wall(nr, nc):
            continue
        if (nr, nc) == t1 or (nr, nc) == t2:
            continue

        player = (nr, nc)

        # Rule 2: pick up the gift.
        if player == GIFT:
            has_gift = True

        # Rule 3: gift + exit -> immediate clear, thieves do not move.
        if player == EXIT and has_gift:
            return True, "clear"

        # Rule 4: exit without gift -> no clear, game keeps going (thieves still move).

        # Rule 5: thief1 then thief2 each step toward the player.
        dist = bfs(player)
        t1 = move_thief(t1, t2, dist)
        if t1 == player:
            return False, "caught"
        t2 = move_thief(t2, t1, dist)
        if t2 == player:
            return False, "caught"

    return False, "no_clear"


# ---------------------------------------------------------------------------
# Routes
# ---------------------------------------------------------------------------
@app.route("/")
def index():
    return render_template("index.html")


@app.route("/api/clear", methods=["POST"])
def clear():
    data = request.get_json(silent=True) or {}
    moves = data.get("moves", "")

    if not isinstance(moves, str):
        return jsonify({"success": False, "message": "잘못된 요청입니다."}), 400
    if len(moves) > MAX_MOVES:
        return jsonify({"success": False, "message": "이동 기록이 너무 깁니다."}), 400
    if any(ch not in DELTA for ch in moves):
        return jsonify({"success": False, "message": "허용되지 않은 입력입니다."}), 400

    cleared, _reason = simulate(moves)
    if cleared:
        flag = os.environ.get("FLAG", "XMAS{test_flag}")
        return jsonify({"success": True, "flag": flag})
    return jsonify({"success": False, "message": "탈출에 실패했습니다. 다시 시도하세요."})


if __name__ == "__main__":
    app.run(host="0.0.0.0", port=8020)
