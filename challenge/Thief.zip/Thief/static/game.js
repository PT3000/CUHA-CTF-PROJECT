"use strict";

/* ------------------------------------------------------------------ *
 * Game definition — MUST stay identical to app.py                     *
 * ------------------------------------------------------------------ */
const MAZE = [
  "###########",
  "#..G#.....#",
  "###.#.#P###",
  "#T........#",
  "#.#.#.###.#",
  "#.T...#...#",
  "#.###.#.#.#",
  "#......E..#",
  "#.#.#.#.#.#",
  "#.........#",
  "###########",
];
const ROWS = MAZE.length;
const COLS = MAZE[0].length;

const START_PLAYER = [2, 7];
const START_THIEF1 = [3, 1];
const START_THIEF2 = [5, 2];
const GIFT = [1, 3];
const EXIT = [7, 7];

const ORDER = ["U", "D", "L", "R"];
const DELTA = { U: [-1, 0], D: [1, 0], L: [0, -1], R: [0, 1] };
const MAX_MOVES = 500;

function isWall(r, c) {
  if (r < 0 || r >= ROWS || c < 0 || c >= COLS) return true;
  return MAZE[r][c] === "#";
}
const eq = (a, b) => a[0] === b[0] && a[1] === b[1];

function bfs(src) {
  const dist = Array.from({ length: ROWS }, () => new Array(COLS).fill(-1));
  dist[src[0]][src[1]] = 0;
  const q = [src];
  let head = 0;
  while (head < q.length) {
    const [r, c] = q[head++];
    for (const d of ORDER) {
      const [dr, dc] = DELTA[d];
      const nr = r + dr, nc = c + dc;
      if (isWall(nr, nc)) continue;
      if (dist[nr][nc] === -1) {
        dist[nr][nc] = dist[r][c] + 1;
        q.push([nr, nc]);
      }
    }
  }
  return dist;
}

function moveThief(thief, other, dist) {
  const [cr, cc] = thief;
  const cur = dist[cr][cc];
  for (const d of ORDER) {
    const [dr, dc] = DELTA[d];
    const nr = cr + dr, nc = cc + dc;
    if (isWall(nr, nc)) continue;
    if (nr === other[0] && nc === other[1]) continue;
    const nd = dist[nr][nc];
    if (nd !== -1 && nd < cur) return [nr, nc];
  }
  return thief;
}

/* ------------------------------------------------------------------ *
 * Mutable game state                                                  *
 * ------------------------------------------------------------------ */
let player, t1, t2, hasGift, moveCount, movesLog, over;

function reset() {
  player = START_PLAYER.slice();
  t1 = START_THIEF1.slice();
  t2 = START_THIEF2.slice();
  hasGift = false;
  moveCount = 0;
  movesLog = "";
  over = false;
  setStatus("화살표 키 또는 WASD로 움직이세요.", "");
  render();
}

/* Perform one player step. Mirrors simulate() in app.py. */
function step(dir) {
  if (over) return;
  const [dr, dc] = DELTA[dir];
  const nr = player[0] + dr, nc = player[1] + dc;

  // Rule 1: illegal moves are ignored.
  if (isWall(nr, nc)) return;
  if (eq([nr, nc], t1) || eq([nr, nc], t2)) return;

  player = [nr, nc];
  moveCount += 1;
  movesLog += dir;

  // Rule 2: gift pickup.
  if (eq(player, GIFT)) hasGift = true;

  // Rule 3: gift + exit -> clear, thieves frozen.
  if (eq(player, EXIT) && hasGift) {
    over = true;
    render();
    submitClear();
    return;
  }

  // Rule 4: exit without gift -> warn, game continues.
  let warn = eq(player, EXIT) && !hasGift;

  // Rule 5: thieves move (thief1 then thief2).
  const dist = bfs(player);
  t1 = moveThief(t1, t2, dist);
  if (eq(t1, player)) return caught();
  t2 = moveThief(t2, t1, dist);
  if (eq(t2, player)) return caught();

  render();
  if (warn) {
    setStatus("선물을 먹고 출구로 나가세요", "warn");
  } else if (hasGift) {
    setStatus("선물을 챙겼어요! 출구로 가세요.", "");
  } else {
    setStatus("도둑을 피해 선물을 먼저 찾으세요.", "");
  }
}

function caught() {
  over = true;
  render();
  setStatus("도둑에게 잡혔어요!", "lose");
}

/* ------------------------------------------------------------------ *
 * Server verification                                                 *
 * ------------------------------------------------------------------ */
async function submitClear() {
  setStatus("탈출 확인 중...", "");
  try {
    const res = await fetch("/api/clear", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ moves: movesLog }),
    });
    const data = await res.json();
    if (data.success) {
      setStatus("탈출 성공! " + data.flag, "win");
    } else {
      setStatus(data.message || "검증에 실패했습니다.", "lose");
    }
  } catch (e) {
    setStatus("서버에 연결할 수 없습니다.", "lose");
  }
}

/* ------------------------------------------------------------------ *
 * Icons (inline SVG, no external assets)                              *
 * ------------------------------------------------------------------ */
const ICONS = {
  player: `<svg viewBox="0 0 24 24" fill="none"><circle cx="12" cy="6.5" r="3.3" fill="#4f9dff"/><path d="M5 20c0-4 3.1-6.5 7-6.5s7 2.5 7 6.5" fill="#4f9dff"/></svg>`,
  thief: `<svg viewBox="0 0 24 24" fill="none"><circle cx="12" cy="7" r="3.3" fill="#ff5a5a"/><rect x="6.5" y="5.2" width="11" height="3.1" rx="1.5" fill="#101826"/><path d="M5 20c0-4 3.1-6.5 7-6.5s7 2.5 7 6.5" fill="#ff5a5a"/></svg>`,
  gift: `<svg viewBox="0 0 24 24" fill="none"><rect x="4" y="9" width="16" height="11" rx="1.5" fill="#ffd34d"/><rect x="3" y="6.5" width="18" height="3.5" rx="1" fill="#ffe27a"/><rect x="10.7" y="4" width="2.6" height="16" fill="#e0932a"/><path d="M12 6.5C9 6.5 8 3.5 10 3c1.6-.4 2 2 2 3.5 0-1.5.4-3.9 2-3.5 2 .5 1 3.5-2 3.5z" fill="#e0932a"/></svg>`,
  exit: `<svg viewBox="0 0 24 24" fill="none"><rect x="6" y="3.5" width="12" height="17" rx="1.5" fill="#4cd68a"/><rect x="7.6" y="5.2" width="8.8" height="13.6" rx="1" fill="#2f9e63"/><circle cx="14.4" cy="12" r="1.1" fill="#eafff2"/></svg>`,
};

/* ------------------------------------------------------------------ *
 * Rendering                                                           *
 * ------------------------------------------------------------------ */
const boardEl = document.getElementById("board");
const statusEl = document.getElementById("status");
const legendEl = document.getElementById("legend");

function cellContent(r, c) {
  if (eq([r, c], player)) return ICONS.player;
  if (eq([r, c], t1) || eq([r, c], t2)) return ICONS.thief;
  if (!hasGift && eq([r, c], GIFT)) return ICONS.gift;
  if (eq([r, c], EXIT)) return ICONS.exit;
  return "";
}

function render() {
  const frag = document.createDocumentFragment();
  for (let r = 0; r < ROWS; r++) {
    for (let c = 0; c < COLS; c++) {
      const div = document.createElement("div");
      const wall = MAZE[r][c] === "#";
      div.className = "cell " + (wall ? "wall" : "floor");
      if (eq([r, c], EXIT)) div.classList.add("exit-cell");
      const ic = cellContent(r, c);
      if (ic) div.innerHTML = `<span class="icon">${ic}</span>`;
      frag.appendChild(div);
    }
  }
  boardEl.replaceChildren(frag);

  legendEl.innerHTML =
    `<span class="item">${scaled(ICONS.player)} 나</span>` +
    `<span class="item">${scaled(ICONS.thief)} 도둑 2명</span>` +
    `<span class="item">${scaled(ICONS.gift)} 선물</span>` +
    `<span class="item">${scaled(ICONS.exit)} 출구</span>` +
    `<span class="item moves">이동 ${moveCount}</span>`;
}

function scaled(svg) {
  return svg.replace("<svg ", '<svg width="18" height="18" ');
}

function setStatus(msg, cls) {
  statusEl.textContent = msg;
  statusEl.className = "status" + (cls ? " " + cls : "");
}

/* ------------------------------------------------------------------ *
 * Input                                                               *
 * ------------------------------------------------------------------ */
const KEYMAP = {
  ArrowUp: "U", ArrowDown: "D", ArrowLeft: "L", ArrowRight: "R",
  w: "U", s: "D", a: "L", d: "R",
  W: "U", S: "D", A: "L", D: "R",
};

window.addEventListener("keydown", (e) => {
  const dir = KEYMAP[e.key];
  if (dir) {
    e.preventDefault();
    step(dir);
  }
});

document.querySelectorAll(".pad").forEach((btn) => {
  btn.addEventListener("click", () => step(btn.dataset.dir));
});

document.getElementById("restart").addEventListener("click", reset);

reset();
