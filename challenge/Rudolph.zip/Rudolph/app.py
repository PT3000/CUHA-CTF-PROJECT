"""루돌프의 깜빡임 - XMAS CTF 웹 챌린지

정답 확인은 전적으로 서버에서만 이루어진다.
정답 문자열과 플래그는 어떤 응답에도(HTML/JS/헤더) 노출되지 않는다.
단, 정답을 맞춘 참가자에게만 플래그가 표시된다.
"""
import hmac
import os
import threading
import time
from collections import deque

from flask import Flask, render_template, request

# --- 설정 ---------------------------------------------------------------
# 정답은 서버 코드에만 존재한다(정규화된 형태로 저장).
# 클라이언트로는 절대 전송되지 않는다.
_ANSWER_NORMALIZED = "MERRYCHRISTMAS"

# 플래그는 코드에 넣지 않고 환경변수에서만 읽는다.
FLAG = os.environ.get("FLAG")
if not FLAG:
    raise RuntimeError(
        "환경변수 FLAG가 설정되지 않았습니다. "
        ".env 파일에 FLAG=... 를 지정한 뒤 서버를 실행하세요."
    )

MAX_INPUT_LENGTH = 100          # 입력 허용 최대 길이(초과 시 오답 처리)
RATE_LIMIT_MAX = 120            # IP당 허용 요청 수
RATE_LIMIT_WINDOW = 60          # 시간 창(초) -> 분당 120회

# --- 메시지 -------------------------------------------------------------
MSG_WRONG = "루돌프가 고개를 갸웃거려요..."
MSG_RATE_LIMITED = "루돌프가 지쳤어요. 잠시 후 다시 시도해 주세요"

app = Flask(__name__)


# --- Rate limit (메모리 기반, 외부 라이브러리 없음) --------------------
# IP -> 최근 요청 시각(deque). 슬라이딩 윈도우로 오래된 기록을 제거한다.
# gunicorn 멀티 워커 환경에서는 워커별 카운터이지만, 한도를 넉넉히
# 잡았으므로 챌린지 운영에는 충분하다.
_rate_lock = threading.Lock()
_rate_hits: dict[str, deque] = {}


def _client_ip() -> str:
    """요청 클라이언트 IP. 리버스 프록시 뒤에서는 remote_addr가
    프록시 주소가 될 수 있다(README 참고)."""
    return request.remote_addr or "unknown"


def _rate_limited(ip: str) -> bool:
    """이번 요청을 기록하고, 윈도우 내 한도를 초과하면 True."""
    now = time.monotonic()
    cutoff = now - RATE_LIMIT_WINDOW
    with _rate_lock:
        hits = _rate_hits.get(ip)
        if hits is None:
            hits = deque()
            _rate_hits[ip] = hits
        # 윈도우를 벗어난 오래된 기록 제거
        while hits and hits[0] <= cutoff:
            hits.popleft()
        if len(hits) >= RATE_LIMIT_MAX:
            return True
        hits.append(now)
        # 메모리 누수 방지: 활동이 없는 IP 항목을 가끔 정리
        if len(_rate_hits) > 10000:
            _prune_idle(cutoff)
    return False


def _prune_idle(cutoff: float) -> None:
    """윈도우 내 기록이 하나도 없는 IP 항목을 제거(락 보유 중 호출)."""
    for key in [k for k, v in _rate_hits.items() if not v or v[-1] <= cutoff]:
        del _rate_hits[key]


# --- 정답 판정 ----------------------------------------------------------
def _normalize(value: str) -> str:
    """앞뒤/중간 공백을 모두 제거하고 대문자로 변환."""
    return "".join(value.split()).upper()


def _is_correct(raw: str) -> bool:
    if len(raw) > MAX_INPUT_LENGTH:
        return False
    guess = _normalize(raw)
    # 타이밍 공격 방지를 위해 compare_digest 사용
    return hmac.compare_digest(guess, _ANSWER_NORMALIZED)


# --- 라우트 -------------------------------------------------------------
@app.route("/", methods=["GET", "POST"])
def index():
    result = None          # "correct" | "wrong" | "rate_limited" | None
    flag = None
    submitted = ""

    if request.method == "POST":
        if _rate_limited(_client_ip()):
            result = "rate_limited"
        else:
            submitted = request.form.get("answer", "")
            if _is_correct(submitted):
                result = "correct"
                flag = FLAG
            else:
                result = "wrong"

    response = app.make_response(
        render_template(
            "index.html",
            result=result,
            flag=flag,
            wrong_message=MSG_WRONG,
            rate_limited_message=MSG_RATE_LIMITED,
            max_length=MAX_INPUT_LENGTH,
            submitted=submitted,
        )
    )
    # 캐시 방지(정답 제출 결과가 중간 캐시에 남지 않도록)
    response.headers["Cache-Control"] = "no-store"
    return response


if __name__ == "__main__":
    # 개발용 직접 실행. 운영 환경은 gunicorn 사용(Dockerfile 참고).
    app.run(host="0.0.0.0", port=5000, debug=False)
