# 🦌 루돌프의 깜빡임 (Rudolph's Blink)

고등학생 대상 XMAS CTF 웹 챌린지. 루돌프의 코가 모스부호로 깜빡이며 메시지를
전한다. 참가자는 영상을 분석해 모스부호를 해독하고, 정답 문자열을 입력하면
플래그를 획득한다.

- **카테고리:** Web / Misc (Steganography)
- **정답:** `MERRYCHRISTMAS`
- **플래그:** `.env` 파일의 `FLAG` 값 (기본 `XMAS{...}`)

## 동작 방식 / 보안

- 정답 판정은 **전적으로 서버(`app.py`)에서만** 이루어진다. 정답 문자열과
  플래그는 HTML·JS·응답 헤더 어디에도 노출되지 않으며, 정답을 맞춘 참가자에게만
  플래그가 표시된다. (페이지 소스 보기로는 풀 수 없음)
- 플래그는 코드에 하드코딩하지 않고 **환경변수 `FLAG`** 에서 읽는다. `FLAG`가
  없으면 서버는 에러로 즉시 종료된다.
- 입력 정규화: 앞뒤·중간 공백을 모두 제거하고 대문자로 변환해 비교하므로
  `merry christmas`, `MerryChristmas`, `MERRYCHRISTMAS` 모두 정답으로 처리된다.
- 입력이 **100자를 초과**하면 오답 처리된다.
- 비교는 `hmac.compare_digest`로 타이밍 공격을 방지한다.
- Jinja2 autoescape가 켜져 있어(`|safe` 미사용) 입력값 반사로 인한 XSS가 없다.
- **Rate limit:** 같은 IP 기준 **분당 120회**. 메모리 기반 슬라이딩 윈도우이며
  외부 라이브러리를 쓰지 않는다. 초과 시 "루돌프가 지쳤어요..." 메시지를 보여준다.
  (같은 학교 Wi-Fi로 IP가 겹칠 수 있어 넉넉하게 설정)

## 실행 방법 (Docker)

```bash
# 1) .env 파일에 플래그가 설정되어 있는지 확인
cat .env            # FLAG=XMAS{...}

# 2) 빌드 및 실행
docker compose up -d --build

# 3) 접속
# http://localhost:8003
```

중지:

```bash
docker compose down
```

## 플래그 변경 방법

`.env` 파일의 `FLAG` 값을 수정한 뒤 컨테이너를 다시 띄운다.

```bash
# .env 수정 후
docker compose up -d --force-recreate
```

> `.env`는 `.gitignore`에 포함되어 있어 저장소에 커밋되지 않는다.

## 로컬 개발 실행 (Docker 없이)

```bash
pip install -r requirements.txt

# FLAG 환경변수가 반드시 필요하다(없으면 서버가 종료됨)
# Linux/macOS
export FLAG='XMAS{2pdDohMDuwiLRWi1}'
# Windows PowerShell
#   $env:FLAG = 'XMAS{2pdDohMDuwiLRWi1}'

python app.py
# http://localhost:5000
```

## 구조

```
.
├── app.py              # Flask 앱 (정답 판정 · rate limit)
├── templates/
│   └── index.html      # 페이지 (autoescape 유지)
├── static/
│   ├── rudolph.mp4     # 루돌프 영상
│   └── style.css       # 스타일 (크리스마스 분위기 · 눈 효과)
├── requirements.txt
├── Dockerfile          # python:3.12-slim · gunicorn · 비root 유저
├── docker-compose.yml  # env_file로 .env 주입
├── .env                # FLAG (커밋 금지)
├── .gitignore
└── README.md
```

## 리버스 프록시 참고

Rate limit은 `request.remote_addr`(접속 IP)를 기준으로 한다. nginx 등 리버스
프록시 뒤에 둘 경우 모든 요청이 프록시 IP로 보일 수 있으니, 프록시에서
`X-Forwarded-For`를 세팅하고 애플리케이션 쪽에서 신뢰할 수 있는 프록시에 한해
해당 헤더를 참조하도록 조정해야 한다. (직접 노출 또는 Docker 포트 퍼블리시
환경에서는 그대로 동작한다.)
