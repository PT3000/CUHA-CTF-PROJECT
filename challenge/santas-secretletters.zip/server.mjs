import { readFile } from "node:fs/promises";
import { createServer } from "node:http";
import { Readable } from "node:stream";
import { handle, signingKey } from "./game.mjs";

const defaultLetters = new URL("../santas-secret-letters-organizer/private/letters.json", import.meta.url);

function readOrigin(value) {
  if (!value) return null;
  const url = new URL(value);
  if (!["http:", "https:"].includes(url.protocol) || url.origin + "/" !== url.href) {
    throw new Error("SANTA_PUBLIC_ORIGIN must be an HTTP(S) origin, e.g. https://game.example.org");
  }
  return url.origin;
}

async function loadGame() {
  const secret = process.env.SANTA_SESSION_KEY || "";
  if (Buffer.byteLength(secret) < 32) {
    throw new Error("SANTA_SESSION_KEY must be at least 32 bytes. Run node init-env.mjs and load .env.");
  }
  const letters = JSON.parse(await readFile(process.env.SANTA_LETTERS_FILE || defaultLetters, "utf8"));
  if (!Array.isArray(letters) || letters.length !== 4) {
    throw new Error("Expected four entries in the private letters file.");
  }
  const flags = letters.map((letter, index) => {
    const matches = typeof letter?.translation === "string" && letter.translation.match(/FLAG\{[a-z0-9_]+\}/g);
    if (matches?.length !== 1 || !/^letter_0[1-4]_[a-z]+\.txt$/.test(letter.filename) ||
        typeof letter.text !== "string" || !Array.isArray(letter.hints) || letter.hints.length !== 2 ||
        !letter.hints.every(hint => typeof hint === "string" && hint.length)) {
      throw new Error("Invalid private letter at stage " + (index + 1));
    }
    return matches[0];
  });
  if (new Set(flags).size !== flags.length) throw new Error("Each stage needs its own flag.");
  const assets = {};
  for (const [filename, type] of [
    ["index.html", "text/html"], ["shell.js", "text/javascript"],
    ["style.css", "text/css"], ["postage.css", "text/css"]
  ]) {
    const path = filename === "index.html" ? "/" : "/" + filename;
    assets[path] = { type: type + "; charset=utf-8", body: await readFile(new URL("./public/" + filename, import.meta.url)) };
  }
  return { letters, flags, assets, key: await signingKey(secret) };
}

async function start() {
  const game = await loadGame();
  const publicOrigin = readOrigin(process.env.SANTA_PUBLIC_ORIGIN);
  const port = Number(process.env.PORT || "8080");
  if (!Number.isInteger(port) || port < 0 || port > 65535) throw new Error("Invalid PORT.");
  const host = process.env.HOST || "127.0.0.1";
  const server = createServer({ requestTimeout: 30_000, headersTimeout: 15_000 }, async (incoming, outgoing) => {
    let request;
    try {
      if (!incoming.url.startsWith("/") || /[\\\r\n]/.test(incoming.url)) {
        throw new Error("Invalid request path.");
      }
      const origin = publicOrigin || readOrigin("http://" + incoming.headers.host);
      const init = { method: incoming.method, headers: incoming.headers };
      if (incoming.method === "POST") {
        init.body = Readable.toWeb(incoming);
        init.duplex = "half";
      }
      request = new Request(origin + incoming.url, init);
    } catch {
      outgoing.writeHead(400).end();
      return;
    }
    try {
      const response = await handle(request, game);
      outgoing.writeHead(response.status, Object.fromEntries(response.headers));
      outgoing.end(Buffer.from(await response.arrayBuffer()));
    } catch {
      if (!outgoing.headersSent) outgoing.writeHead(500);
      outgoing.end();
      console.error("Request handling failed.");
    }
  });
  server.on("error", error => { console.error(error.message); process.exitCode = 1; });
  server.listen(port, host, () => console.log("Listening on " + host + ":" + server.address().port));
}

start().catch(error => { console.error("Startup failed:", error.message); process.exitCode = 1; });
