"use strict";

const guides = [
  ['첫 번째 지령 · 선물', '굴뚝 옆 쪽지를 읽고 챙겨 갈 선물의 꼬리표를 찾아 줘.'],
  ['두 번째 지령 · 주소', '선물은 챙겼어. 이번에는 배달할 집의 주소를 찾아 줘.'],
  ['세 번째 지령 · 이름', '주소는 확인했어. 산타의 일기에서 선물을 받을 아이의 이름을 찾아 줘.'],
  ['네 번째 지령 · 도착 시각', '이제 누구에게 전할지 알았어. 마지막 편지에서 썰매가 지붕에 내릴 시각을 찾아 줘.']
];
const usage = {
  body: 'body [파일]', caesar: 'caesar 이동수 [파일]', atbash: 'atbash [파일]',
  base64: 'base64 [파일]', freq: 'freq [파일]', subst: 'subst 암호문자 평문문자 [파일]',
  vigenere: 'vigenere 영문키 [파일]', hex: 'hex [파일]', reverse: 'reverse [파일]', rot47: 'rot47 [파일]'
};
const helpText = [
  '편지함   ls                  열린 파일 목록',
  '         pwd / cd 폴더       현재 위치 / 이동 (.. 상위, ~ 홈)',
  '         cat [파일]          산타의 쪽지와 암호문 읽기',
  '         body [파일]         암호문만 꺼내기',
  '         brief               지금 풀 편지와 제출 형식 확인',
  '         hint weak / strong  지금 편지의 약한 / 강한 힌트',
  '         story [번호]        제출을 마친 편지의 한국어 번역 다시 읽기',
  '         submit FLAG{...}    정답 확인 후 다음 편지 열기',
  '',
  '작업 도구 (명령어 이름순)',
  '         atbash              알파벳의 양 끝에서 서로 짝이 되는 글자로 바꾸기',
  '         base64              Base64로 인코딩된 글 읽기',
  '         caesar 이동수        알파벳을 지정한 칸만큼 뒤로 밀기',
  '         freq                글자 빈도 세기',
  '         grep [-in] "검색어" [파일]   일치하는 줄 찾기',
  '         hex                 두 자리씩 적힌 16진수에서 글 읽기',
  '         paste               복호화 입력칸에 붙여 넣은 글 읽기',
  '         reverse             글을 끝에서 처음 순서로 뒤집기',
  '         rot47               영문 인쇄 문자와 기호를 47칸씩 회전하기',
  '         subst 암호문자 평문문자    대응한 글자만 바꿔 읽기',
  '         vigenere 영문키      반복 키로 편지 풀기',
  '',
  '복호화 명령은 끝에 파일을 지정할 수 있어요. 생략하면 현재 문제의 암호문을 씁니다.',
  '파이프(|)는 앞 명령의 출력을 다음 명령으로 보내요. 예: ls | grep ".txt"',
  '> 파일은 결과를 저장하고, >> 파일은 기존 내용 뒤에 덧붙여요. < 파일은 그 내용을 입력으로 읽어요.',
  '예: ls > files.txt  다음 줄에서  cat < files.txt',
  '내 파일은 이 탭의 홈(~)과 편지함(~/letters)에 저장돼요. ls로 찾고 cat 파일명으로 읽으세요.',
  'Tab 파일명 완성 · ↑↓ 명령 기록 · history 기록 보기 · clear 화면 지우기'
].join('\n');

function createShell(files, runExtra) {
  const home = '/home/elf';
  const directories = new Set(['/', '/home', home, home + '/letters']);
  // Official letters follow server progress. Scratch files belong to this tab.
  let scratch = new Map();
  const storageKey = 'santa-dispatch.scratch.v1';
  const capacity = 512 * 1024;
  let storage;
  try { storage = globalThis.sessionStorage; } catch { /* Memory storage is still available. */ }
  const commands = [
    'atbash', 'base64', 'body', 'caesar', 'cat', 'cd', 'clear', 'freq', 'grep',
    'help', 'hex', 'hint', 'history', 'ls', 'paste', 'pwd', 'reverse', 'rot47', 'story', 'submit', 'subst', 'vigenere', 'whoami', 'start', 'brief'
  ];
  const history = [];
  let cwd = home + '/letters';
  let previous = null;
  try {
    const saved = storage?.getItem(storageKey);
    if (saved && saved.length <= capacity) {
      const entries = JSON.parse(saved);
      for (const [path, contents] of entries) {
        if (typeof path === 'string' && typeof contents === 'string' && outputPath(path) === path) {
          scratch.set(path, contents);
        }
      }
    }
  } catch { /* Ignore malformed or unavailable browser storage. */ }
  function parent(path) {
    return path.slice(0, path.lastIndexOf('/')) || '/';
  }

  function basename(path) {
    return path.slice(path.lastIndexOf('/') + 1);
  }

  function resolve(raw) {
    if (raw === '~' || raw.startsWith('~/')) raw = home + raw.slice(1);
    const full = raw.startsWith('/') ? raw : cwd + '/' + raw;
    const parts = [];
    for (const part of full.split('/')) {
      if (part === '..') parts.pop();
      else if (part && part !== '.') parts.push(part);
    }
    return '/' + parts.join('/');
  }

  function outputPath(raw) {
    const path = resolve(raw);
    if (!raw || raw.endsWith('/') || directories.has(path) || /[\x00-\x1F\x7F]/.test(raw)) {
      throw Error('결과를 저장할 파일 이름을 입력하세요.');
    }
    if (Object.hasOwn(files, path) || /^letter_\d+_.*\.txt$/i.test(basename(path))) {
      throw Error('산타의 편지는 읽기 전용이에요. 다른 파일 이름을 써 주세요.');
    }
    if (parent(path) !== home && parent(path) !== home + '/letters') {
      throw Error('홈(~)이나 편지함(~/letters)에 파일을 저장하세요.');
    }
    return path;
  }

  function writeOutput(path, text, append) {
    const data = text && !text.endsWith('\n') ? text + '\n' : text;
    const contents = (append ? scratch.get(path) ?? '' : '') + data;
    const next = new Map(scratch).set(path, contents);
    const serialized = JSON.stringify([...next]);
    if (serialized.length > capacity) throw Error('작업 파일 공간이 가득 찼어요. > 로 긴 파일을 짧게 덮어쓰세요.');
    if (storage) {
      try { storage.setItem(storageKey, serialized); }
      catch { throw Error('브라우저에서 파일을 저장할 수 없어요. 저장 공간을 확인해 주세요.'); }
    }
    scratch = next;
  }

  function children(folder) {
    return [...directories, ...Object.keys(files), ...scratch.keys()]
      .filter(path => path !== '/' && parent(path) === folder)
      .sort((a, b) => Number(directories.has(b)) - Number(directories.has(a)) || a.localeCompare(b, 'en'));
  }

  function read(raw) {
    let path = resolve(raw);
    if (!raw.includes('/') && !Object.hasOwn(files, path) && !scratch.has(path)) {
      const inMailbag = home + '/letters/' + raw;
      if (Object.hasOwn(files, inMailbag)) path = inMailbag;
    }
    if (directories.has(path)) throw Error(raw + '은(는) 폴더입니다.');
    if (!Object.hasOwn(files, path) && !scratch.has(path)) throw Error('파일을 찾을 수 없습니다: ' + raw);
    if (raw.endsWith('/')) throw Error('폴더가 아닙니다: ' + raw);
    return {path, text: scratch.get(path) ?? files[path]};
  }

  // Keep token offsets so completion can replace just the active word.
  function tokenize(line, partial = false) {
    const groups = [[]];
    let word = '';
    let start = -1;
    let quote = '';
    function endWord() {
      if (start < 0) return;
      groups[groups.length - 1].push({value: word, start, end: cursor});
      start = -1;
      word = '';
    }
    let cursor = 0;
    for (; cursor < line.length; cursor++) {
      const ch = line[cursor];
      if (!quote && (ch === '|' || /\s/.test(ch))) {
        endWord();
        if (ch === '|') groups.push([]);
        continue;
      }
      if (!quote && (ch === '<' || ch === '>')) {
        endWord();
        const operatorStart = cursor;
        if (ch === '>' && line[cursor + 1] === '>') cursor++;
        groups.at(-1).push({operator: line.slice(operatorStart, cursor + 1), start: operatorStart, end: cursor + 1});
        continue;
      }
      if (start < 0) start = cursor;
      if (ch === '\\' && quote !== "'") {
        if (cursor + 1 < line.length) word += line[++cursor];
        else if (!partial) throw Error('역슬래시 뒤에 문자를 입력하세요.');
      } else if (ch === quote) {
        quote = '';
      } else if (!quote && (ch === "'" || ch === '"')) {
        quote = ch;
      } else {
        word += ch;
      }
    }
    if (quote && !partial) throw Error('따옴표를 닫아 주세요.');
    endWord();
    return groups;
  }

  function parseOptions(args, allowed, usage) {
    const flags = new Set();
    let i = 0;
    while (i < args.length && args[i].startsWith('-') && args[i] !== '-') {
      const option = args[i++];
      if (option === '--') break;
      for (const flag of option.slice(1)) {
        if (!allowed.includes(flag)) throw Error('지원하지 않는 옵션: -' + flag + '\n사용법: ' + usage);
        flags.add(flag);
      }
    }
    return {flags, rest: args.slice(i)};
  }

  function list(args) {
    const {flags, rest} = parseOptions(args, 'al', 'ls [-al] [경로 …]');
    const paths = rest.length ? rest : ['.'];
    function format(path, name) {
      const directory = directories.has(path);
      const label = name + (directory ? '/' : '');
      if (!flags.has('l')) return label;
      const size = directory ? '—' : String(new TextEncoder().encode(scratch.get(path) ?? files[path]).length);
      const permissions = directory ? 'dr-xr-xr-x' : scratch.has(path) ? '-rw-------' : '-r--r--r--';
      return permissions + '  ' + size.padStart(5) + '  ' + label;
    }
    return paths.map(raw => {
      const path = resolve(raw);
      if (!directories.has(path)) {
        return format(read(raw).path, raw);
      }
      const entries = children(path)
        .filter(child => flags.has('a') || !basename(child).startsWith('.'))
        .map(child => format(child, basename(child)));
      if (flags.has('a')) entries.unshift(format(path, '.'), format(parent(path), '..'));
      if (paths.length > 1) entries.unshift(raw + ':');
      return entries.join('\n');
    }).join('\n\n');
  }

  function search(args, stdin, openFile) {
    const {flags, rest} = parseOptions(args, 'in', 'grep [-in] 검색어 [파일 …]');
    if (!rest.length || (rest.length === 1 && stdin === null)) {
      throw Error('사용법: grep [-in] "검색어" 파일  또는  명령 | grep [-in] "검색어"');
    }
    const fold = value => flags.has('i') ? value.toLowerCase() : value;
    const pattern = fold(rest[0]);
    const sources = rest.length === 1
      ? [{label: '', text: stdin}]
      : rest.slice(1).map(raw => ({label: raw, text: openFile(raw).text}));
    const matches = [];
    for (const {label, text} of sources) {
      const lines = text === '' ? [] : text.split(/\r?\n/);
      if (lines.length && lines[lines.length - 1] === '') lines.pop();
      lines.forEach((line, index) => {
        if (!fold(line).includes(pattern)) return;
        const file = sources.length > 1 ? label + ':' : '';
        matches.push(file + (flags.has('n') ? (index + 1) + ':' : '') + line);
      });
    }
    return matches.join('\n');
  }

  async function execute(command, args, stdin, openFile) {
    switch (command) {
      case 'help': return {text: helpText};
      case 'pwd': return {text: cwd};
      case 'whoami': return {text: 'elf'};
      case 'clear': return {text: '', clear: true};
      case 'history': return {text: history.map((item, i) => String(i + 1).padStart(3) + '  ' + item).join('\n')};
      case 'ls': return {text: list(args)};
      case 'cd': {
        if (args.length > 1) throw Error('사용법: cd [폴더]');
        const raw = args[0] ?? '~';
        if (raw === '-' && previous === null) throw Error('이전 위치가 없습니다.');
        const path = raw === '-' ? previous : resolve(raw);
        if (!directories.has(path)) throw Error(Object.hasOwn(files, path) || scratch.has(path) ? '폴더가 아닙니다: ' + raw : '폴더를 찾을 수 없습니다: ' + raw);
        previous = cwd;
        cwd = path;
        return {text: raw === '-' ? path : ''};
      }
      case 'cat': {
        if (!args.length && stdin === null) return {text: currentLetter().text.trimEnd()};
        return {text: args.length ? args.map(raw => openFile(raw).text.replace(/\r?\n$/, '')).join('\n') : stdin};
      }
      case 'grep': return {text: search(args, stdin, openFile)};
      default: {
        if (commands.includes(command) && runExtra) {
          const result = await runExtra(command, args, {read: openFile, stdin, resolve, home, cwd});
          if (result) return result;
        }
        throw Error('알 수 없는 명령: ' + command + '\n사용 가능한 명령은 help로 확인하세요.');
      }
    }
  }

  function parseGroup(tokens, index, total) {
    const words = [];
    let input = null;
    let output = null;
    for (let i = 0; i < tokens.length; i++) {
      const {operator, value} = tokens[i];
      if (!operator) {
        words.push(value);
        continue;
      }
      const target = tokens[++i];
      if (!target?.value) throw Error(operator + ' 뒤에 파일명을 입력하세요.');
      if (operator === '<') {
        if (index !== 0 || input !== null) throw Error('입력 파일은 첫 명령에 < 파일명으로 한 번만 지정하세요.');
        input = target.value;
      } else {
        if (index !== total - 1 || output !== null) throw Error('결과 파일은 마지막 명령에 > 또는 >>로 한 번만 지정하세요.');
        output = {name: target.value, append: operator === '>>'};
      }
    }
    const [command, ...args] = words;
    if (!command) throw Error('명령어를 입력하세요. 예: cat < memo.txt');
    if (['cd', 'clear', 'submit'].includes(command) && (total > 1 || input !== null || output)) {
      throw Error('cd, clear, submit은 단독으로 실행하세요.');
    }
    return {command, args, input, output};
  }

  async function run(line) {
    if (!line.trim()) return {text: ''};
    history.push(line);
    if (history.length > 200) history.shift();
    const opened = new Set();
    function openFile(raw) {
      const result = read(raw);
      opened.add(result.path);
      return result;
    }
    try {
      const groups = tokenize(line);
      if (groups.some(group => !group.length)) throw Error('| 양쪽에 명령이 필요합니다.');
      const stages = groups.map((group, index) => parseGroup(group, index, groups.length));
      const output = stages.at(-1).output;
      const targetPath = output && outputPath(output.name);
      const input = stages[0].input;
      let stdin = input === null ? null : openFile(input).text;
      let result;
      for (const {command, args} of stages) {
        result = await execute(command, args, stdin, openFile);
        for (const path of result.opened || []) opened.add(path);
        if (result.kind === 'error') return {...result, opened: [...opened]};
        stdin = result.text;
      }
      if (output) {
        writeOutput(targetPath, result.text, output.append);
        return {text: '', opened: [...opened]};
      }
      return {...result, command: stages.at(-1).command, opened: [...opened]};
    } catch (error) {
      return {kind: 'error', text: error.message, opened: [...opened]};
    }
  }

  function complete(line) {
    const group = tokenize(line, true).at(-1);
    const last = group.at(-1);
    const active = last && !last.operator && last.end === line.length ? last : {start: line.length, value: ''};
    const previous = group.filter(token => token.start < active.start);
    const redirect = previous.at(-1)?.operator;
    const words = previous.filter((token, i) => !token.operator && !previous[i - 1]?.operator).map(token => token.value);
    const prefix = active.value;
    let choices;
    if (!words.length && !redirect) {
      choices = commands.filter(name => name.startsWith(prefix));
    } else {
      const command = words[0];
      if (command === 'hint' && !redirect) choices = (words.length === 1 ? ['weak', 'strong', ...Object.keys(files).map((_, index) => String(index + 1))] : ['weak', 'strong']).filter(x => x.startsWith(prefix));
      else {
        const pathArgs = {ls: 0, cd: 0, cat: 0, grep: 1, body: 0, caesar: 1, base64: 0, atbash: 0, freq: 0, hex: 0, reverse: 0, rot47: 0, subst: 2, vigenere: 1};
        const args = words.slice(1).filter(word => !word.startsWith('-'));
        if (!redirect && (!Object.hasOwn(pathArgs, command) || args.length < pathArgs[command] || prefix.startsWith('-'))) {
          return {line, choices: []};
        }
        if (prefix === '~') choices = ['~/'];
        else {
          const slash = prefix.lastIndexOf('/') + 1;
          const head = prefix.slice(0, slash);
          const tail = prefix.slice(slash);
          choices = children(resolve(head || '.'))
            .filter(path => basename(path).startsWith(tail) && (command !== 'cd' || directories.has(path)))
            .filter(path => !redirect?.startsWith('>') || !Object.hasOwn(files, path))
            .map(path => head + basename(path) + (directories.has(path) ? '/' : ''));
          if (command === 'cd' && (tail === '.' || tail === '..')) {
            choices.push(head + '../');
            if (tail === '.') choices.push(head + './');
          }
        }
      }
    }
    if (!choices.length) return {line, choices};
    let common = choices[0];
    while (!choices.every(choice => choice.startsWith(common))) common = common.slice(0, -1);
    const only = choices.length === 1;
    if (!only && common.length <= prefix.length) return {line, choices};
    const escaped = common.replace(/[\s|<>'"\\]/g, ch => '\\' + ch);
    return {line: line.slice(0, active.start) + escaped + (only && !common.endsWith('/') ? ' ' : ''), choices: only ? [] : choices};
  }

  return {run, complete, get cwd() { return cwd; }, get history() { return history; }};
}

function transformLetters(text, transform) {
  return text.replace(/[a-z]/gi, (letter) => {
    const start = letter >= 'a' ? 97 : 65;
    return String.fromCharCode(start + transform(letter.charCodeAt(0) - start));
  });
}

function applySubstitution(text, encoded, decoded) {
  const normalize = (value) => value.replace(/\s+/g, '').toUpperCase();
  const source = normalize(encoded);
  const target = normalize(decoded);
  if (!/^[A-Z]+$/.test(source) || !/^[A-Z]+$/.test(target) || source.length !== target.length) {
    throw new Error('길이가 같은 두 영문 글자열을 입력하세요. 예: subst ABC XYZ [파일]');
  }
  const mapping = new Map();
  const used = new Set();
  for (let index = 0; index < source.length; index++) {
    const from = source[index];
    const to = target[index];
    if (mapping.has(from) && mapping.get(from) === to) continue;
    if (mapping.has(from) || used.has(to)) {
      throw new Error('치환표에서 한 글자에 서로 다른 짝이 지정됐습니다.');
    }
    mapping.set(from, to);
    used.add(to);
  }
  return text.replace(/[a-z]/gi, (letter) => {
    const paired = mapping.get(letter.toUpperCase());
    return paired ? (letter >= 'a' ? paired.toLowerCase() : paired) : '·';
  });
}

function decodeEvidence(command, args, text) {
  if (command === 'body') return text;
  if (command === 'reverse') return Array.from(text).reverse().join('');
  if (command === 'rot47') {
    return text.replace(/[!-~]/g, letter =>
      String.fromCharCode(33 + (letter.charCodeAt(0) - 33 + 47) % 94));
  }
  if (command === 'hex') {
    const digits = text.replace(/\s+/g, '');
    if (!/^(?:[0-9a-f]{2})+$/i.test(digits)) {
      throw Error('16진수는 0~9와 A~F를 두 자리씩 입력하세요.');
    }
    const bytes = Uint8Array.from(digits.match(/../g), pair => Number.parseInt(pair, 16));
    try {
      return new TextDecoder('utf-8', { fatal: true }).decode(bytes);
    } catch {
      throw Error('16진수가 UTF-8 글자를 나타내는지 확인하세요.');
    }
  }
  if (command === 'base64') {
    try {
      const binary = atob(text.replace(/\s+/g, ''));
      const bytes = Uint8Array.from(binary, (char) => char.charCodeAt(0));
      return new TextDecoder('utf-8', { fatal: true }).decode(bytes);
    } catch {
      throw new Error('Base64로 인코딩된 UTF-8 텍스트인지 확인하세요.');
    }
  }
  if (command === 'atbash') return transformLetters(text, (index) => 25 - index);
  if (command === 'caesar') {
    if (!/^[+-]?\d+$/.test(args[0]) || !Number.isSafeInteger(Number(args[0]))) {
      throw new Error('이동수에는 정수를 입력하세요.');
    }
    const shift = Number(args[0]) % 26;
    return transformLetters(text, (index) => (index - shift + 26) % 26);
  }
  if (command === 'vigenere') {
    if (!/^[A-Za-z]+$/.test(args[0])) throw new Error('키에는 영문자만 사용할 수 있습니다.');
    const key = Array.from(args[0].toUpperCase(), (letter) => letter.charCodeAt(0) - 65);
    let position = 0;
    return transformLetters(text, (index) => (index - key[position++ % key.length] + 26) % 26);
  }
  if (command === 'subst') return applySubstitution(text, args[0], args[1]);
  if (command !== 'freq') throw Error('사용할 방식을 선택하세요.');
  const counts = new Map();
  for (const letter of text.toUpperCase().match(/[A-Z]/g) || []) {
    counts.set(letter, (counts.get(letter) || 0) + 1);
  }
  const ranked = [...counts.entries()].sort(([a, n], [b, m]) => m - n || a.localeCompare(b));
  return ranked.map(([letter, count]) => letter + '  ' + count).join('\n') || '본문에 영문자가 없습니다.';
}

const fileTable = Object.create(null);
let state = null;
const shell = createShell(fileTable, runExtra);
const element = (...ids) => ids.map(id => document.getElementById(id)).find(Boolean);
const input = element('command', 'command-input');
const transcript = element('transcript');
const form = element('shell-form');
let running = false;

function currentIndex() {
  return Math.min(state.solved, 3);
}
function currentLetter() {
  if (!state) throw Error('우체국에 연결 중이에요. 잠시 뒤 start를 입력하세요.');
  return state.letters[currentIndex()];
}
function brief() {
  const letter = currentLetter();
  if (state.solved === 4) return '수석 요정의 메모\n배달 완료! 아이가 뚜껑을 열자 첫 음이 울렸어. 할머니가 곡을 흥얼거리는 동안 아이는 산타의 편지를 펼쳤대. 메리 크리스마스, 꼬마 요정!\n첫 편지 번역은 story 1로 다시 읽어 봐.';
  const [name, goal] = guides[currentIndex()];
  return '수석 요정의 메모 · ' + name + '\n' + goal + '\n편지 열기   cat ' + letter.filename + '\n제출 형식   submit FLAG{...}';
}
function setLabel(ids, text) {
  const node = element(...ids);
  if (node) node.textContent = text;
}
function promptPath() {
  return shell.cwd.replace(/^\/home\/elf(?=\/|$)/, '~');
}
function refreshView() {
  setLabel(['prompt', 'prompt-path'], promptPath() + ' $');
  if (!state) return;
  const index = currentIndex();
  const done = state.solved === guides.length;
  const [name, goal] = guides[index];
  setLabel(['progress', 'stage-count'], state.solved + ' / 4');
  setLabel(['goal-title'], done ? '배달 완료' : name);
  setLabel(['goal', 'goal-text'], done ? '아이에게 첫 편지가 도착했어. 네 편지 모두 다시 읽을 수 있어.' : goal);
  setLabel(['submit-format', 'goal-format'], done ? '네 편지 모두 해결' : 'submit FLAG{...}');
  setLabel(['current-file'], currentLetter().filename);
  setLabel(['connection', 'connection-status'], '연결됨');
  const download = element('download-current');
  if (download) {
    download.href = '/api/letters/' + (index + 1) + '/download';
    download.download = currentLetter().filename;
  }
  for (const step of document.querySelectorAll('[data-stage]')) {
    const number = Number(step.dataset.stage);
    const status = number <= state.solved ? 'done' : number === index + 1 ? 'current' : 'locked';
    step.dataset.state = status;
    if (status === 'current') step.setAttribute('aria-current', 'step');
    else step.removeAttribute('aria-current');
    const badge = step.querySelector('.stage-status');
    if (badge) badge.textContent = {done: '완료', current: '현재', locked: '잠김'}[status];
  }
}
function updateState(newState) {
  if (!Number.isInteger(newState?.solved) || newState.solved < 0 || newState.solved > 4 ||
      !Array.isArray(newState.letters) || newState.letters.length !== Math.min(4, newState.solved + 1)) {
    throw Error('편지함을 읽지 못했어요. start로 다시 연결해 주세요.');
  }
  const unlockedChanged = state?.letters.length !== newState.letters.length;
  state = newState;
  for (const path of Object.keys(fileTable)) delete fileTable[path];
  for (const letter of state.letters) fileTable['/home/elf/letters/' + letter.filename] = letter.text;
  if (unlockedChanged) updateDecoderLetters();
  refreshView();
}
async function sync() {
  const response = await fetch('/api/state', {cache: 'no-store'});
  if (!response.ok) throw Error('편지함에 연결할 수 없어요. start를 다시 입력해 주세요.');
  updateState(await response.json());
}
function payload(text) {
  const divider = /\r?\n---\r?\n/.exec(text);
  return divider ? text.slice(divider.index + divider[0].length).replace(/\r?\n$/, '') : text;
}

const sourceLetter = element('source-letter');
const buffer = element('cipher-buffer');
const method = element('method');
const substPreview = element('subst-preview');
const decoderTranslation = element('decoder-translation');
const translationText = element('translation-text');
const translationHeading = '수석 요정의 번역';
const translationRetry = '번역을 불러오지 못했어. 제출을 마친 편지는 story와 편지 번호로 다시 읽을 수 있어.';
let decoderRevision = 0;
const hintMappings = new Map();
let mappingFilename;
function decodedFlag(text) {
  return text.match(/FLAG\{[a-z0-9_]+\}/)?.[0];
}
async function translationForFlag(answer) {
  const response = await fetch('/api/translation', {
    method: 'POST', headers: {'Content-Type': 'application/json'},
    body: JSON.stringify({answer})
  });
  if (response.status === 422 || response.status === 403) return null;
  if (!response.ok) throw Error(translationRetry);
  return response.json();
}
function clearDecoderTranslation() {
  decoderRevision++;
  decoderTranslation.hidden = true;
  translationText.textContent = '';
}
async function showDecoderTranslation(text) {
  const answer = decodedFlag(text);
  if (!answer) return;
  const revision = decoderRevision;
  try {
    const result = await translationForFlag(answer);
    if (revision !== decoderRevision || !result) return;
    translationText.textContent = result.translation;
    decoderTranslation.hidden = false;
  } catch {
    if (revision === decoderRevision) decoderNote(translationRetry, true);
  }
}
function fillMapping(starter) {
  element('decode-seal').value = starter?.cipher ?? '';
  element('decode-plain').value = starter?.plain ?? '';
}
function showKeyFields() {
  clearDecoderTranslation();
  element('shift-row').hidden = method.value !== 'caesar';
  element('name-row').hidden = method.value !== 'vigenere';
  element('seal-row').hidden = method.value !== 'subst';
  substPreview.hidden = true;
}
function resetDecoderChoice() {
  const index = Number(sourceLetter.value);
  const letter = state.letters[index];
  if (letter.filename !== mappingFilename) {
    fillMapping(hintMappings.get(letter.filename));
    element('decode-shift').value = '';
    element('decode-key').value = '';
    mappingFilename = letter.filename;
  }
  method.value = '';
  showKeyFields();
  decoderNote('암호문을 불러오거나 붙여 넣은 뒤 사용할 방식을 선택하세요.');
}
function updateDecoderLetters() {
  sourceLetter.replaceChildren(...state.letters.map((letter, index) => new Option(letter.filename, String(index))));
  sourceLetter.value = String(currentIndex());
  resetDecoderChoice();
  element('copy-current').disabled = false;
  element('load-cipher').disabled = false;
  element('copy-note').textContent = '';
  element('manual-copy').hidden = true;
}
function bufferText() {
  if (!buffer.value.trim()) throw Error('복호화 입력칸에 암호문을 붙여 넣거나 편지를 불러오세요.');
  return buffer.value;
}
function decoderNote(message, error = false) {
  const note = element('decode-note');
  note.textContent = message;
  note.toggleAttribute('data-error', error);
}
method.addEventListener('change', showKeyFields);
for (const field of [buffer, element('decode-shift'), element('decode-key'), element('decode-seal'), element('decode-plain')]) {
  field.addEventListener('input', () => {
    substPreview.hidden = true;
    clearDecoderTranslation();
  });
}
sourceLetter.addEventListener('change', resetDecoderChoice);
element('load-cipher').addEventListener('click', () => {
  const letter = state.letters[Number(sourceLetter.value)];
  buffer.value = payload(letter.text);
  resetDecoderChoice();
  decoderNote(letter.filename + '의 암호문을 불러왔어요. 사용할 방식을 선택하세요.');
});
element('count-letters').addEventListener('click', () => {
  clearDecoderTranslation();
  try {
    substPreview.textContent = decodeEvidence('freq', [], bufferText());
    substPreview.hidden = false;
    decoderNote('많이 나온 글자부터 정렬했어요. 반복되는 짧은 단어와 함께 살펴보세요.');
  } catch (error) {
    decoderNote(error.message, true);
  }
});
element('decode-once').addEventListener('click', () => {
  clearDecoderTranslation();
  try {
    if (!method.value) throw Error('사용할 방식을 선택하세요.');
    const original = bufferText();
    let args = [];
    if (method.value === 'caesar') args = [element('decode-shift').value];
    if (method.value === 'vigenere') args = [element('decode-key').value.trim()];
    if (method.value === 'subst') {
      const preview = applySubstitution(original, element('decode-seal').value, element('decode-plain').value);
      substPreview.textContent = preview;
      substPreview.hidden = false;
      const letter = state?.letters[Number(sourceLetter.value)];
      const tag = letter && hintMappings.has(letter.filename) && original === payload(letter.text) && preview.match(/FLAG\{[a-z·]+\}/);
      if (tag) {
        decoderNote('이름표  ' + tag[0] + (tag[0].includes('·')
          ? '  ·  강한 힌트의 반복 단어를 확인하고, 두 줄 끝에 글자 한 쌍을 더해 보세요.'
          : '  ·  일기의 단어들도 맞게 읽히는지 확인한 뒤 제출하세요.'));
      } else {
        decoderNote('아래에서 치환 결과를 읽어 보세요. 두 줄에 글자 짝을 더하고 다시 누르면 같은 암호문으로 확인할 수 있어요.');
      }
      return showDecoderTranslation(preview);
    }
    buffer.value = decodeEvidence(method.value, args, original);
    decoderNote('입력칸에 결과가 있어요. 다른 방식을 고르면 이 결과에 이어서 적용할 수 있어요.');
    return showDecoderTranslation(buffer.value);
  } catch (error) {
    decoderNote(error.message, true);
  }
});
async function copyText(text, note, fallback) {
  try {
    await navigator.clipboard.writeText(text);
    element('manual-copy').hidden = true;
    note.textContent = '복사했어요.';
  } catch {
    fallback.value = text;
    fallback.hidden = false;
    fallback.focus();
    fallback.select();
    note.textContent = '글을 선택했어요. Ctrl+C 또는 기기의 복사 메뉴를 사용하세요.';
  }
}
element('copy-current').addEventListener('click', () =>
  copyText(payload(currentLetter().text), element('copy-note'), element('manual-copy')));
element('copy-buffer').addEventListener('click', () => {
  if (!buffer.value) return decoderNote('복사할 글을 먼저 입력하세요.', true);
  decoderNote('');
  return copyText(buffer.value, element('decode-note'), buffer);
});
async function runExtra(command, args, context) {
  if (command === 'start') {
    await sync();
    return {text: brief()};
  }
  if (command === 'brief') return {text: brief()};
  if (command === 'story') {
    if (args.length > 1 || (args.length && !/^[1-4]$/.test(args[0]))) {
      throw Error('사용법: story [1~4 사이의 편지 번호]');
    }
    const stage = args.length ? Number(args[0]) : state?.solved;
    if (!stage || stage > (state?.solved ?? 0)) throw Error('플래그를 제출한 편지의 번역을 다시 읽을 수 있어.');
    const response = await fetch('/api/letters/' + stage + '/translation', {cache: 'no-store'});
    if (!response.ok) throw Error(translationRetry);
    const result = await response.json();
    return {kind: 'story', text: translationHeading + ' · ' + stage + '번 편지\n' + result.translation};
  }
  if (command === 'paste') {
    if (args.length || context.stdin !== null) throw Error('입력칸의 글을 읽으려면 paste를 맨 앞에 쓰세요.');
    return {text: bufferText()};
  }
  const letter = currentLetter();
  if (command === 'hint') {
    const parts = [...args];
    const stage = /^\d+$/.test(parts[0]) ? Number(parts.shift()) : currentIndex() + 1;
    const strength = parts.shift() || 'weak';
    if (parts.length || !['weak', 'strong'].includes(strength)) throw Error('사용법: hint [편지 번호] weak 또는 hint [편지 번호] strong');
    const available = state.letters[stage - 1];
    if (!available) throw Error('열린 편지의 힌트만 읽을 수 있어요.');
    const response = await fetch('/api/letters/' + stage + '/hints/' + strength, {cache: 'no-store'});
    if (!response.ok) throw Error('힌트를 불러올 수 없어요. 잠시 뒤 다시 시도해 주세요.');
    const result = await response.json();
    if (result.substitutionStarter) {
      hintMappings.set(available.filename, result.substitutionStarter);
      if (mappingFilename === available.filename && !element('decode-seal').value && !element('decode-plain').value) {
        fillMapping(result.substitutionStarter);
      }
    }
    const level = strength === 'weak' ? '약한 힌트' : '강한 힌트';
    return {text: '수석 요정의 메모 · ' + level + '\n' + result.hint.replaceAll('\x60', '')};
  }
  if (command === 'submit') {
    if (state.solved === 4) return {text: brief(), kind: 'success'};
    if (!args.length) return {text: brief()};
    const response = await fetch('/api/submit', {
      method: 'POST',
      headers: {'Content-Type': 'application/json'},
      body: JSON.stringify({stage: state.solved + 1, answer: args.join(' ')})
    });
    const result = await response.json();
    if (!response.ok) {
      if (response.status === 409) await sync();
      throw Error((result.error || '제출을 처리하지 못했어요.') + '\n' + brief());
    }
    updateState(result);
    const message = state.solved === 4 ? brief() : '정답! 다음 봉투를 열었어.\n' + brief();
    return {kind: 'success', submittedAnswer: args.join(' ').trim(),
      text: message + '\nCTFd ' + result.solved + '번 문제에도 방금 찾은 플래그를 제출하면 점수가 기록돼.'};
  }
  if (!Object.hasOwn(usage, command)) return null;
  if (command === 'subst' && (args.length <= 1 || args[0] === '+')) {
    const extending = args[0] === '+';
    if (extending && (args.length > 4 || !/^[A-Za-z]$/.test(args[1] ?? '') || !/^[A-Za-z]$/.test(args[2] ?? ''))) {
      throw Error('사용법: subst + 암호글자 원래글자 [일기 파일]');
    }
    const filename = args[extending ? 3 : 0];
    if (filename && context.stdin !== null) throw Error('파이프 입력과 파일명 중 하나를 골라 주세요.');
    const path = filename ? context.read(filename).path : null;
    const entry = filename ? state.letters.find(item => path === context.home + '/letters/' + item.filename) : letter;
    const starter = entry && hintMappings.get(entry.filename);
    if (!starter) throw Error('직접 찾은 글자 짝을 입력하세요. 사용법: ' + usage.subst);
    args = [
      starter.cipher + (extending ? args[1] : ''),
      starter.plain + (extending ? args[2] : '')
    ];
    if (filename) args.push(filename);
  }
  const parameterCount = {caesar: 1, vigenere: 1, subst: 2}[command] || 0;
  const filename = args[parameterCount];
  if (args.length < parameterCount || args.length > parameterCount + 1 || (filename && context.stdin !== null)) {
    throw Error('사용법: ' + usage[command]);
  }
  const source = context.stdin ?? (filename ? context.read(filename).text : letter.text);
  const fromLetter = state.letters.some(item => item.text.trimEnd() === source.trimEnd());
  const text = fromLetter ? payload(source) : source;
  return {text: decodeEvidence(command, args, text)};
}
function print(text, kind = 'output') {
  if (!text && kind !== 'translation') return;
  const line = document.createElement('pre');
  line.className = 'entry ' + kind;
  line.textContent = text;
  line.hidden = !text;
  transcript.append(line);
  if (transcript.children.length > 250) transcript.firstElementChild.remove();
  if (text) transcript.scrollTop = transcript.scrollHeight;
  return line;
}
function scrollToStory(entry) {
  if (entry.getBoundingClientRect) {
    transcript.scrollTop += entry.getBoundingClientRect().top - transcript.getBoundingClientRect().top - 8;
  }
}
const terminalTranslations = new Map();
let commandSequence = 0;
async function showTerminalTranslation(answer, afterSubmit = false) {
  const previous = terminalTranslations.get(answer);
  if (!answer || (afterSubmit && previous && previous.isConnected !== false)) return;
  const sequence = commandSequence;
  const entry = print('', 'translation');
  terminalTranslations.set(answer, entry);
  try {
    const result = await translationForFlag(answer);
    if (result) {
      const following = transcript.scrollTop + transcript.clientHeight >= transcript.scrollHeight - 5;
      entry.textContent = translationHeading + ' · ' + result.stage + '번 편지\n' + result.translation;
      entry.hidden = false;
      if (following && commandSequence === sequence) scrollToStory(entry);
      return;
    }
    entry.remove?.();
  } catch {
    entry.textContent = translationRetry;
    entry.hidden = false;
  }
  if (terminalTranslations.get(answer) === entry) terminalTranslations.delete(answer);
}
let historyIndex = 0;
let draft = '';
async function send(line) {
  if (running || !line.trim()) return;
  running = true;
  commandSequence++;
  print('elf@northpole:' + promptPath() + ' $ ' + line, 'command-line command');
  let translation;
  try {
    const result = await shell.run(line.trim());
    if (result.clear) {
      transcript.replaceChildren();
      terminalTranslations.clear();
    } else if (result.kind === 'story') {
      scrollToStory(print(result.text, 'translation'));
    } else {
      if (result.submittedAnswer) translation = showTerminalTranslation(result.submittedAnswer, true);
      print(result.text, 'output ' + (result.kind || ''));
      if (!result.kind && (Object.hasOwn(usage, result.command) || ['cat', 'grep', 'paste'].includes(result.command))) {
        translation = showTerminalTranslation(decodedFlag(result.text));
      }
    }
    refreshView();
  } finally {
    historyIndex = shell.history.length;
    draft = '';
    running = false;
  }
  await translation;
}
form.addEventListener('submit', event => {
  event.preventDefault();
  if (running) return;
  const line = input.value;
  input.value = '';
  void send(line);
});
for (const button of document.querySelectorAll('[data-run]')) {
  button.addEventListener('click', () => void send(button.dataset.run));
}
for (const button of document.querySelectorAll('[data-fill]')) {
  button.addEventListener('click', () => {
    input.value = button.dataset.fill;
    input.focus();
  });
}
element('read-current')?.addEventListener('click', () => {
  if (state) void send('cat ' + currentLetter().filename);
  else void send('start');
});
input.addEventListener('keydown', event => {
  if (event.isComposing || event.ctrlKey || event.altKey || event.metaKey || event.shiftKey) return;
  if (event.key === 'ArrowUp' || event.key === 'ArrowDown') {
    event.preventDefault();
    if (historyIndex === shell.history.length) draft = input.value;
    const delta = event.key === 'ArrowUp' ? -1 : 1;
    historyIndex = Math.max(0, Math.min(shell.history.length, historyIndex + delta));
    input.value = shell.history[historyIndex] ?? draft;
    input.setSelectionRange(input.value.length, input.value.length);
  }
  if (event.key === 'Tab' && input.value && input.selectionStart === input.value.length) {
    const result = shell.complete(input.value);
    if (result.line !== input.value || result.choices.length) {
      event.preventDefault();
      input.value = result.line;
      if (result.choices.length) print(result.choices.join('   '), 'output muted');
    }
  }
});
refreshView();
async function boot() {
  try {
    await sync();
    print(brief());
  } catch {
    setLabel(['connection', 'connection-status'], '연결 필요');
    print('우체국과 연결이 끊겼어요. start를 입력해 다시 연결하세요.', 'output error');
  }
}
void boot();
