const lifetime = 30 * 24 * 60 * 60;
const encoder = new TextEncoder();

function json(value, status = 200, extra = {}) {
  return new Response(JSON.stringify(value), {
    status,
    headers: {
      "Content-Type": "application/json; charset=utf-8",
      "Cache-Control": "private, no-store",
      "Vary": "Cookie",
      "X-Content-Type-Options": "nosniff",
      ...extra
    }
  });
}

function error(message, status, extra) {
  return json({ error: message }, status, extra);
}

function handout({ filename, text }) {
  return { filename, text };
}

function state(solved, letters) {
  return { solved, letters: letters.slice(0, solved + 1).map(handout) };
}

export function signingKey(secret) {
  return crypto.subtle.importKey("raw", encoder.encode(secret),
    { name: "HMAC", hash: "SHA-256" }, false, ["sign", "verify"]);
}

async function readProgress(request, key, cookieName) {
  const cookies = (request.headers.get("Cookie") || "").split(";").map(part => part.trim());
  const cookie = cookies.find(part => part.startsWith(cookieName + "="));
  if (!cookie) return 0;
  const token = cookie.slice(cookieName.length + 1);
  const match = /^dispatch1\.([1-4])\.(\d{10})\.([a-f0-9]{64})$/.exec(token);
  if (!match || Number(match[2]) <= Math.floor(Date.now() / 1000)) return 0;
  const signature = Uint8Array.from(match[3].match(/../g), pair => Number.parseInt(pair, 16));
  const signed = token.slice(0, token.lastIndexOf("."));
  const valid = await crypto.subtle.verify("HMAC", key, signature, encoder.encode(signed));
  return valid ? Number(match[1]) : 0;
}

function progressCookieName(secure) {
  return secure ? "__Host-santa-dispatch-progress" : "santa-dispatch-progress";
}

async function progressCookie(solved, key, secure) {
  const expiry = Math.floor(Date.now() / 1000) + lifetime;
  const signed = `dispatch1.${solved}.${expiry}`;
  const bytes = new Uint8Array(await crypto.subtle.sign("HMAC", key, encoder.encode(signed)));
  const signature = Array.from(bytes, byte => byte.toString(16).padStart(2, "0")).join("");
  return `${progressCookieName(secure)}=${signed}.${signature}; Max-Age=${lifetime}; Path=/; HttpOnly; SameSite=Lax${secure ? "; Secure" : ""}`;
}

function translatedLetter(stage, letters) {
  return json({ stage, translation: letters[stage - 1].translation });
}

async function readSubmission(request) {
  const limit = 1024;
  if (!request.body || Number(request.headers.get("Content-Length")) > limit) return null;
  const reader = request.body.getReader();
  const bytes = new Uint8Array(limit);
  let length = 0;
  try {
    for (;;) {
      const { value, done } = await reader.read();
      if (done) break;
      if (length + value.length > limit) {
        await reader.cancel();
        return null;
      }
      bytes.set(value, length);
      length += value.length;
    }
    return JSON.parse(new TextDecoder("utf-8", { fatal: true }).decode(bytes.subarray(0, length)));
  } catch {
    return null;
  } finally {
    reader.releaseLock();
  }
}

export async function handle(request, { letters, flags, assets, key }) {
  const url = new URL(request.url);
  const path = url.pathname === "/index.html" ? "/" : url.pathname;
  if (Object.hasOwn(assets, path)) {
    if (request.method !== "GET" && request.method !== "HEAD") {
      return error("지원하지 않는 요청입니다.", 405, { Allow: "GET, HEAD" });
    }
    const asset = assets[path];
    return new Response(request.method === "HEAD" ? null : asset.body, {
      headers: { "Content-Type": asset.type, "Cache-Control": "no-cache", "X-Content-Type-Options": "nosniff" }
    });
  }

  const letter = /^\/api\/letters\/([1-4])(?:\/(download|translation)|\/hints\/(weak|strong))?$/.exec(path);
  const proofRequest = path === "/api/translation";
  const needsAnswer = path === "/api/submit" || proofRequest;
  if (!letter && !needsAnswer && path !== "/api/state") return error("파일을 찾을 수 없습니다.", 404);
  const method = needsAnswer ? "POST" : "GET";
  if (request.method !== method) return error("지원하지 않는 요청입니다.", 405, { Allow: method });
  const secure = url.protocol === "https:";
  const solved = await readProgress(request, key, progressCookieName(secure));
  if (letter) {
    const number = Number(letter[1]);
    if (number > solved + 1) return error("아직 잠긴 편지입니다. 앞 편지의 답을 먼저 제출해 주세요.", 403);
    const entry = letters[number - 1];
    if (letter[2] === "translation") {
      if (number > solved) return error("꼬리표를 제출한 편지의 번역을 다시 읽을 수 있어요.", 403);
      return translatedLetter(number, letters);
    }
    if (letter[3]) {
      const strong = letter[3] === "strong";
      const result = { hint: entry.hints[strong ? 1 : 0] };
      if (strong && entry.substitutionStarter) result.substitutionStarter = entry.substitutionStarter;
      return json(result);
    }
    if (!letter[2]) return json(handout(entry));
    return new Response(entry.text, {
      headers: {
        "Content-Type": "text/plain; charset=utf-8",
        "Content-Disposition": `attachment; filename="${entry.filename}"`,
        "Cache-Control": "private, no-store",
        "Vary": "Cookie",
        "X-Content-Type-Options": "nosniff"
      }
    });
  }
  if (!needsAnswer) return json(state(solved, letters));

  const origin = request.headers.get("Origin");
  if ((origin && origin !== url.origin) || request.headers.get("Sec-Fetch-Site") === "cross-site") {
    return error("이 터미널에서 답을 제출해 주세요.", 403);
  }
  const type = (request.headers.get("Content-Type") || "").split(";")[0].trim().toLowerCase();
  if (type !== "application/json") return error("제출 형식을 확인해 주세요.", 415);
  const body = await readSubmission(request);
  if (!body || typeof body.answer !== "string") return error("편지에서 찾은 꼬리표를 입력해 주세요.", 400);
  if (proofRequest) {
    const stage = flags.indexOf(body.answer.trim()) + 1;
    if (!stage || stage > solved + 1) return error("번역할 편지를 확인하지 못했어요.", 422);
    return translatedLetter(stage, letters);
  }
  if (!Number.isInteger(body.stage) || body.stage < 1 || body.stage > 4) {
    return error("단계 번호와 답을 함께 제출해 주세요.", 400);
  }
  if (body.stage !== solved + 1) {
    return error(solved === 4 ? "네 통을 모두 해결했습니다." : "현재 열려 있는 단계의 답을 제출해 주세요.", 409);
  }
  if (body.answer.trim() !== flags[body.stage - 1]) return error("이번 편지에서 해독한 FLAG{...} 전체를 대소문자까지 그대로 제출하세요.", 422);
  return json(state(body.stage, letters), 200, { "Set-Cookie": await progressCookie(body.stage, key, secure) });
}
