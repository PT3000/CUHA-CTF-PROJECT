# 산타의 비밀 배달 지령서

크리스마스이브, 북극 우체국 요정이 되어 산타가 남긴 영어 편지 네 통을 해독하는 고등학생용 암호학 CTF입니다. 플레이어는 브라우저 터미널에서 암호문을 읽고, 필요할 때 힌트를 열고, 해독한 편지의 한국어 번역을 읽을 수 있습니다.

**웹 게임은 편지를 열고, CTFd는 점수를 기록합니다.** 게임 터미널에서 `submit FLAG{...}`를 입력하면 다음 봉투가 열립니다. CTFd의 해당 문제에는 같은 `FLAG{...}`만 입력합니다. 게임 진행은 같은 브라우저의 쿠키에 저장됩니다.

**기존 게임을 그대로 쓸 때**는 새 게임 서버를 띄울 필요가 없습니다. 운영자 ZIP의 `ctfd-event/01`부터 `04`까지 `challenge.yml` 네 개를 순서대로 CTFd에 등록하면 됩니다. [현재 게임 열기](https://santas-secret-letters.merryparrot8.chatgpt.site/) · [CTFd 등록 방법](ctfd/README.md)

## 1. GitHub에 올리기

`santas-secret-letters-github.zip`을 풀고 그 안의 파일과 폴더를 저장소 루트에 올리세요. 루트에서 이 `README.md`, `Dockerfile`, `server.mjs`, `public/`, `ctfd/`가 보여야 합니다. `.gitignore`와 `.dockerignore`도 포함하세요.

별도로 받은 `santas-secret-letters-organizer.zip`은 운영자 컴퓨터와 게임 서버에서만 풉니다. 두 압축을 각각 같은 이름의 폴더에 풀면 아래 구조가 됩니다.

```text
대회/
├── santas-secret-letters-github/       ← GitHub 저장소
│   ├── server.mjs
│   ├── compose.yaml
│   └── ctfd/
└── santas-secret-letters-organizer/    ← 운영자 전용
    └── private/letters.json
```

## 2. 직접 호스팅할 게임 실행하기

**Node.js 22 이상**이 있으면 다음 명령을 사용하세요. 별도 패키지 설치는 필요 없습니다. `init-env.mjs`는 진행 쿠키에 서명하는 임의 키를 `.env`에 한 번 저장합니다. 같은 대회가 끝날 때까지 이 파일을 보관하세요.

```sh
cd santas-secret-letters-github
node init-env.mjs
node --env-file=.env server.mjs
```

브라우저에서 [로컬 게임](http://localhost:8080)을 열고 `cat letter_01_chimney.txt`를 입력하면 첫 번째 쪽지가 보입니다.

**Docker Compose로 실행**하려면 같은 폴더에서 아래 명령을 사용하세요. 이미 `.env`를 만들었다면 바로 마지막 줄부터 실행하면 됩니다.

```powershell
# Windows PowerShell
docker run --rm -v "${PWD}:/work" -w /work node:22-alpine node init-env.mjs
docker compose up -d --build
```

```sh
# Linux / macOS
docker run --rm --user "$(id -u):$(id -g)" -v "$PWD:/work" -w /work node:22-alpine node init-env.mjs
docker compose up -d --build
```

## 3. 대회 주소 연결하기

참가자용 HTTPS 도메인을 게임 서버에 연결하고 리버스 프록시가 게임의 `/`와 `/api/` 요청을 모두 같은 서버로 보내도록 설정하세요. 게임은 도메인 루트에서 동작합니다. 예를 들어 CTFd가 `ctf.example.org`라면 게임에는 `letters.example.org`를 사용할 수 있습니다. 기본 Compose 설정은 호스트의 `127.0.0.1:8080`으로 연결합니다.

`.env`에 실제 게임 주소를 아래 형식으로 설정한 뒤 Node 프로세스를 다시 시작하거나 `docker compose up -d`를 실행합니다. 기존 서명 키는 계속 사용하세요. GitHub Pages 같은 정적 호스팅만으로는 편지 개방과 플래그 채점 API를 실행할 수 없습니다.

```dotenv
SANTA_PUBLIC_ORIGIN=https://letters.example.org
```

## 4. CTFd에 문제 네 개 등록하기

기본 등록 파일에는 기존 게임 주소가 들어 있습니다. 직접 호스팅한 주소를 쓰려면 Python 3가 있는 운영자 컴퓨터에서 아래 예시 주소를 **참가자가 접속할 게임 주소**로 바꿔 실행하세요. 네 문제의 등록 파일을 운영자 폴더에 갱신합니다.

```sh
python ctfd/prepare.py --game-url https://letters.example.org
```

이후 `ctfcli` 또는 CTFd 관리 화면에서 문제를 등록합니다. 네 문제 모두 같은 게임에 연결하고, 2·3·4번에는 각각 직전 편지를 선행 조건으로 지정합니다. 설치 순서와 점수 설정은 [CTFd 등록 안내](ctfd/README.md)를 따르세요.

참가자는 CTFd의 첫 문제에서 게임을 열고, 터미널과 CTFd에 각각 플래그를 제출합니다. 운영자는 일반 참가자 계정으로 1번 제출 전후에 2번의 잠금이 풀리는지와 점수판을 확인할 수 있습니다. [CTFd 문제 등록 문서](https://docs.ctfd.io/tutorials/challenges/creating-challenges/) · [CTFd 선행 문제 문서](https://docs.ctfd.io/docs/challenges/requirements/)
