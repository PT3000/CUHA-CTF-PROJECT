"""Prepare four private ctfcli challenge definitions for the Christmas terminal."""

import argparse
import json
import re
from pathlib import Path
from urllib.parse import urlsplit


REPO = Path(__file__).resolve().parents[1]
ORGANIZER = REPO.parent / "santas-secret-letters-organizer"
STAGES = (
    ("선물", "letter_01_chimney.txt", "굴뚝 옆 양말에 산타가 남긴 첫 편지가 있다. 편지를 읽고 챙겨 갈 선물의 꼬리표를 찾자."),
    ("배달할 집", "letter_02_mailbox.txt", "요정 우체국에 도착했다. 두 번째 편지에서 배달할 집의 주소 꼬리표를 찾자."),
    ("받을 아이", "letter_03_hay.txt", "마구간에 남은 산타의 일기를 읽고 선물을 받을 아이의 이름표를 찾자."),
    ("도착 시각", "letter_04_ribbon.txt", "이제 썰매를 띄울 차례다. 마지막 편지에서 지붕에 내릴 시각이 적힌 꼬리표를 찾자."),
)


def flags_from_letters(path):
    letters = json.loads(path.read_text(encoding="utf-8-sig"))
    if not isinstance(letters, list) or len(letters) != len(STAGES):
        raise ValueError("운영 파일에 편지 네 통이 있어야 합니다.")
    flags = []
    for number, (letter, (_, filename, _)) in enumerate(zip(letters, STAGES), 1):
        if not isinstance(letter, dict) or letter.get("filename") != filename:
            raise ValueError(f"{number}번 편지의 파일명이나 순서가 다릅니다.")
        flags_in_text = re.findall(r"FLAG\{[a-z0-9_]+\}", letter.get("translation", ""))
        if len(flags_in_text) != 1:
            raise ValueError(f"{number}번 번역에서 정식 플래그 한 개를 읽을 수 없습니다.")
        flags.append(flags_in_text[0])
    if len(set(flags)) != len(flags):
        raise ValueError("편지마다 서로 다른 플래그가 있어야 합니다.")
    return flags


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--game-url", required=True, help="URL of the public game, including https://")
    parser.add_argument("--letters", type=Path, default=ORGANIZER / "private" / "letters.json")
    parser.add_argument("--out", type=Path, default=ORGANIZER / "ctfd-event")
    parser.add_argument("--points", type=int, nargs=4, default=[100] * 4, metavar="N")
    args = parser.parse_args()
    url = urlsplit(args.game_url)
    if (url.scheme not in ("http", "https") or not url.hostname or url.username is not None
            or url.password is not None or re.search(r'[\s<>()\\]', args.game_url)):
        parser.error("--game-url에는 참가자가 열 수 있는 HTTP(S) 게임 주소를 입력하세요.")
    if min(args.points) < 1:
        parser.error("네 단계의 배점은 각각 1점 이상이어야 합니다.")
    out = args.out.resolve()
    if out == REPO or REPO in out.parents:
        parser.error("--out에는 정답을 보관할 공개 소스 폴더 밖의 경로를 지정하세요.")
    try:
        flags = flags_from_letters(args.letters)
        previous = None
        for number, ((title, _, mission), flag, points) in enumerate(zip(STAGES, flags, args.points), 1):
            name = f"산타의 비밀 배달 지령서 {number:02} · {title}"
            instructions = (
                f"{mission}\n\n[북극 우체국 터미널 열기]({args.game_url})\n\n"
                "게임에서는 `submit FLAG{...}`로 봉투를 열고, 이 문제에는 "
                "`FLAG{...}` 부분만 제출하면 점수를 받습니다. 네 편지는 같은 브라우저에서 이어서 플레이하세요."
            )
            definition = {
                "name": name,
                "author": "북극 우체국",
                "attribution": "북극 우체국",
                "category": "Crypto",
                "description": instructions,
                "value": points,
                "type": "standard",
                "connection_info": args.game_url,
                "flags": [{"type": "static", "content": flag, "data": "case_sensitive"}],
                "requirements": [previous] if previous else [],
                "state": "visible",
                "version": "0.1",
            }
            folder = out / f"{number:02}"
            folder.mkdir(parents=True, exist_ok=True)
            # A JSON value is valid YAML. Keep the paragraph block readable for manual setup.
            lines = []
            for key, value in definition.items():
                if key == "description":
                    lines.append("description: |-")
                    lines.extend("  " + line for line in value.splitlines())
                else:
                    lines.append(f"{key}: {json.dumps(value, ensure_ascii=False)}")
            (folder / "challenge.yml").write_text("\n".join(lines) + "\n", encoding="utf-8")
            previous = name
    except (OSError, ValueError) as exc:
        parser.exit(1, f"생성 실패: {exc}\n")
    print(f"CTFd 문제 4개 생성 완료: {out}")


if __name__ == "__main__":
    main()
