# CTFd에 편지 네 통 등록하기

CTFd에서 1번 문제를 열면 게임으로 이동한다. 각 편지를 푼 참가자는 게임 터미널에 `submit FLAG{...}`를 입력해 다음 봉투를 연다. CTFd에는 같은 플래그의 `FLAG{...}`만 제출해 점수를 받고 다음 문제가 열리게 한다. 게임은 브라우저에 진행도를 보관하고, CTFd는 로그인한 참가자나 팀의 점수를 보관한다.

## 1. 운영 파일 선택하기

운영자 ZIP의 `ctfd-event/01/challenge.yml`부터 `04/challenge.yml`까지 네 파일은 현재 [북극 우체국 게임](https://santas-secret-letters.merryparrot8.chatgpt.site/)에 연결되어 있다. 기존 게임을 이용하면 바로 2번 절로 간다. CTFd의 선행 문제 설정은 대회 안에서의 열람과 채점을 제어한다. 공개 게임 주소를 아는 사람은 대회 밖에서도 게임에 접속할 수 있다.

GitHub에 올린 소스로 직접 호스팅하려면 두 ZIP을 같은 상위 폴더에 풀고 게임 서버를 먼저 배포한다. `santas-secret-letters-github` 안에서 아래 명령을 실행한다. 예시 도메인을 참가자가 실제로 열 수 있는 게임 첫 화면 주소로 바꾼다.

```sh
python ctfd/prepare.py --game-url https://game.example.org
```

운영 폴더의 `private/letters.json`에서 네 정답을 읽고 `../santas-secret-letters-organizer/ctfd-event/01/challenge.yml`부터 `04/challenge.yml`까지 만든다. 기본 배점은 각 100점이다. 바꾸려면 명령 끝에 `--points 50 100 150 100`처럼 1~4번 순서로 지정한다. 다시 실행하면 이 네 파일을 새 설정으로 갱신한다. 생성된 YAML에는 실제 정답이 들어 있으므로 운영 폴더에 보관한다.

## 2. 관리자 화면에서 등록하기

1. **Admin Panel → Challenges → +**에서 **Standard** 문제를 만든다. `01/challenge.yml`의 `name`, `category`, `description`, `value`를 각각 이름, 카테고리, 설명, 배점에 입력한다.
2. **Flags**에서 **Static**을 선택하고 `flags` 항목의 `content` 값을 넣는다. 대소문자 구분을 켠다. **Connection Info**에는 `connection_info`의 게임 주소를 넣는다. 참가자용 첨부 파일은 비워 둔다.
3. 같은 방법으로 2, 3, 4번을 순서대로 만든다. 각 문제의 **Requirements**에서 아래 선행 문제를 고르고 잠긴 동안 **Hidden**을 선택한다. 문제가 준비되면 네 문제 자체의 **State**를 **Visible**로 설정한다. [CTFd 문제 생성 안내](https://docs.ctfd.io/tutorials/challenges/creating-challenges/) · [선행 문제 설정](https://docs.ctfd.io/docs/challenges/requirements/)

| 편지 | 알아낼 내용 | 선행 문제 |
| --- | --- | --- |
| 01 | 선물 | 없음 |
| 02 | 배달할 집 | 01 |
| 03 | 받을 아이 | 02 |
| 04 | 도착 시각 | 03 |

## 관리자 화면 대신 ctfcli로 등록하기

운영자 ZIP의 YAML 네 개 또는 새 주소로 갱신한 YAML을 사용한다. 운영 PC에 Git을 설치한 뒤 `santas-secret-letters-github` 폴더에서 아래 명령을 순서대로 실행한다. Windows PowerShell에서는 먼저 `$env:PYTHONUTF8="1"`을 실행해 한글 YAML을 UTF-8로 읽게 한다. `ctf init`은 **CTFd 대회 사이트 주소**와 관리자 액세스 토큰을 묻는다. 토큰과 정답이 저장되는 `ctfd-event` 폴더는 운영 PC에 둔다. [ctfcli 공식 사용법](https://github.com/CTFd/ctfcli) · [challenge.yml 명세](https://github.com/CTFd/ctfcli/blob/0.1.8/ctfcli/spec/challenge-example.yml)

```sh
python -m pip install ctfcli==0.1.8
cd ../santas-secret-letters-organizer/ctfd-event
ctf init
ctf challenge add ./01
ctf challenge add ./02
ctf challenge add ./03
ctf challenge add ./04
ctf challenge install ./01
ctf challenge install ./02
ctf challenge install ./03
ctf challenge install ./04
ctf challenge verify
```

위 설치 명령은 준비된 문제를 **Visible** 상태로 등록한다. 등록 후 주소나 점수가 바뀌면 1번 절의 명령을 다시 실행하고, 이 전용 이벤트 폴더에서 `ctf challenge sync` 및 `ctf challenge verify`를 차례로 실행한다.

## 참가자 화면에서 확인하기

일반 참가자 계정으로 접속해 처음에는 1번만 보이는지 확인한다. 1번 게임 링크를 열어 첫 플래그를 게임과 CTFd 양쪽에 제출한다. 게임에는 두 번째 봉투가, CTFd에는 2번 문제가 열려야 한다. 마지막 제출 후 기본 설정으로는 네 문제의 점수 합계가 400점이다.
