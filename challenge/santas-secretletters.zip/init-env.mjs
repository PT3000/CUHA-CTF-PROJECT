import { randomBytes } from "node:crypto";
import { writeFile } from "node:fs/promises";

const envFile = new URL("./.env", import.meta.url);
const key = randomBytes(32).toString("hex");
try {
  await writeFile(envFile, "SANTA_SESSION_KEY=" + key + "\n", { flag: "wx", mode: 0o600 });
  console.log("Created .env with a new session signing key.");
} catch (error) {
  if (error.code !== "EEXIST") throw error;
  console.log(".env already exists. Kept the existing configuration.");
}
