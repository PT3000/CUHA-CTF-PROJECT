// 눈송이에 랜덤한 위치/속도/크기를 준다. 외부 라이브러리 없음.
(function () {
  var flakes = document.querySelectorAll(".snow span");
  for (var i = 0; i < flakes.length; i++) {
    var f = flakes[i];
    f.style.left = Math.random() * 100 + "vw";
    f.style.fontSize = (Math.random() * 0.9 + 0.6) + "em";
    f.style.animationDuration = (Math.random() * 6 + 6) + "s";
    f.style.animationDelay = (-Math.random() * 12) + "s";
    f.style.opacity = (Math.random() * 0.5 + 0.4).toString();
  }
})();
