import os
import secrets

from flask import (
    Flask,
    redirect,
    render_template,
    request,
    session,
    url_for,
)

app = Flask(__name__)

# 세션 쿠키 서명용 키. 환경변수로 받고, 없으면 실행 시 랜덤 생성.
app.secret_key = os.environ.get("SECRET_KEY") or secrets.token_hex(32)

# 플래그는 환경변수에서만 읽는다. 기본값은 테스트용.
FLAG = os.environ.get("FLAG", "XMAS{RuR7TFYlGRvBnflO}")

# ---------------------------------------------------------------------------
# 공용 체험 계정 (모든 참가자가 공유 -> 사이트는 읽기 전용)
# ---------------------------------------------------------------------------
DEMO_USERNAME = "guest"
DEMO_PASSWORD = "guest"
DEMO_UID = 13  # guest 계정은 13번 학생

# ---------------------------------------------------------------------------
# 학급 데이터 (메모리 내 dict, DB 없음)
#   id: 1~20 순차 정수
#   manito[id] = 그 학생이 "몰래 챙겨줄 친구"의 id
#   마니또 배정은 자기 자신을 뽑지 않는 하나의 사이클로 하드코딩되어 있다.
# ---------------------------------------------------------------------------
NAMES = {
    1: "김민준",
    2: "이서연",
    3: "박지호",
    4: "최수아",
    5: "정우진",
    6: "강하은",
    7: "윤도현",
    8: "임채원",
    9: "한지후",
    10: "오예림",
    11: "서준서",
    12: "신유나",
    13: "guest",
    14: "권민서",
    15: "황시우",
    16: "안소율",
    17: "송재민",
    18: "배다은",
    19: "조현우",
    20: "문가은",
}

# 하나의 20-사이클: 1→4→9→15→2→18→11→6→20→3→7→13→5→19→8→14→10→17→12→16→1
MANITO = {
    1: 4,
    2: 18,
    3: 7,
    4: 9,
    5: 19,
    6: 20,
    7: 13,   # 윤도현 -> guest : 이 학생의 메모에 플래그가 들어간다
    8: 14,
    9: 15,
    10: 17,
    11: 6,
    12: 16,
    13: 5,
    14: 10,
    15: 2,
    16: 1,
    17: 12,
    18: 11,
    19: 8,
    20: 3,
}


def build_memos():
    """학생별 마니또 메모. 7번(guest를 챙기는 학생) 메모에만 플래그를 넣는다."""
    return {
        1: "민서한테 줄 선물 아직 못 샀다… 큰일났네 🎁",
        2: "핫초코 기프티콘 줄까 고민 중 ☕",
        3: "크리스마스에 뭐 입고 가지? 빨간 니트 살까",
        4: "트리 장식 같이 하자고 할까 말까 고민이야 🎄",
        5: "선물 포장지 예쁜 거 찾는 중",
        6: "케이크 예약 성공! 딸기 가득한 걸로 🍰",
        7: f"나 사실 guest 마니또임ㅋㅋ 절대 들키면 안 돼… {FLAG}",
        8: "눈 오면 좋겠다… 화이트 크리스마스 가자 ❄️",
        9: "산타 모자 쓰고 갈 사람 구함ㅋㅋ 🎅",
        10: "롤링페이퍼에 뭐라고 쓰지 한참 고민 중",
        11: "캐럴 플레이리스트 만드는 중 🎵",
        12: "붕어빵 사 먹으면서 선물 뭐 살지 생각했다",
        13: "다들 마니또 잘 챙기고 있지? 나도 열심히 챙기는 중!",
        14: "목도리 색깔 뭐가 좋을까 고민이야",
        15: "파티 때 먹을 과자 잔뜩 사놔야지 🍪",
        16: "손편지 쓰는 중인데 글씨가 영 마음에 안 드네",
        17: "기프티콘이 편하긴 한데 성의 없어 보이려나",
        18: "크리스마스 영화 뭐 볼지 추천받아요 🎬",
        19: "선물 두 개 샀는데 하나는 내가 가질까ㅋㅋ",
        20: "반 친구들이랑 보내는 크리스마스 벌써 설렌다 ✨",
    }


MEMOS = build_memos()


def post_date(student_id):
    """게시글마다 보여줄 고정 날짜 문자열 (12월 분위기, 결정적)."""
    day = (student_id * 7) % 24 + 1
    return f"2025-12-{day:02d}"


def is_logged_in():
    return "uid" in session and session["uid"] in NAMES


# ---------------------------------------------------------------------------
# 라우트
# ---------------------------------------------------------------------------
@app.route("/")
def index():
    if is_logged_in():
        return redirect(url_for("board"))
    return redirect(url_for("login"))


@app.route("/login", methods=["GET", "POST"])
def login():
    if is_logged_in():
        return redirect(url_for("board"))

    error = None
    if request.method == "POST":
        username = request.form.get("username", "")
        password = request.form.get("password", "")
        if username == DEMO_USERNAME and password == DEMO_PASSWORD:
            session["uid"] = DEMO_UID
            return redirect(url_for("board"))
        error = "아이디 또는 비밀번호가 올바르지 않아요."

    return render_template(
        "login.html",
        error=error,
        demo_username=DEMO_USERNAME,
        demo_password=DEMO_PASSWORD,
    )


@app.route("/logout")
def logout():
    session.clear()
    return redirect(url_for("login"))


@app.route("/board")
def board():
    """게시판 목록. 로그인한 본인 글만 열람 가능하고, 나머지는 '비공개'로 잠겨 보인다."""
    if not is_logged_in():
        return redirect(url_for("login"))

    my_uid = session["uid"]
    rows = []
    for sid in range(1, len(NAMES) + 1):
        rows.append(
            {
                "id": sid,
                "is_mine": sid == my_uid,
                # 작성자 이름은 공개한다. (글 제목/내용/마니또 배정은 본인 글만 열람 가능)
                "author": NAMES[sid],
                "date": post_date(sid),
            }
        )

    return render_template(
        "board.html",
        rows=rows,
        my_uid=my_uid,
        my_name=NAMES[my_uid],
    )


@app.route("/post")
def post():
    # 로그인 여부만 확인한다.
    # (의도된 취약점 IDOR: 세션 uid 와 id 파라미터가 같은지는 검사하지 않는다)
    if not is_logged_in():
        return redirect(url_for("login"))

    raw_id = request.args.get("id", "")
    try:
        student_id = int(raw_id)
    except (TypeError, ValueError):
        return render_template("error.html"), 404

    if student_id not in NAMES:
        return render_template("error.html"), 404

    target_id = MANITO[student_id]
    return render_template(
        "post.html",
        student_id=student_id,
        student_name=NAMES[student_id],
        target_name=NAMES[target_id],
        memo=MEMOS[student_id],
        date=post_date(student_id),
        is_mine=student_id == session["uid"],
    )


@app.errorhandler(404)
def not_found(_e):
    return render_template("error.html"), 404


if __name__ == "__main__":
    # 개발용 실행. 운영 배포는 gunicorn을 사용한다. (debug 모드 비활성)
    app.run(host="0.0.0.0", port=5000, debug=False)
