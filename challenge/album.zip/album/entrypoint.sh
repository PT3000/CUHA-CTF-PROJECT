#!/bin/sh
# 컨테이너 시작 시 FLAG 환경변수를 웹 루트 바깥(/flag.txt)에 기록한다.
# 플래그는 웹에서 직접 접근할 수 없고, 오직 웹쉘 RCE 로만 읽을 수 있다.

: "${FLAG:=XMAS{default_flag_change_me}}"

echo "$FLAG" > /flag.txt
chmod 644 /flag.txt
chown root:root /flag.txt

# 전달받은 명령 실행 (기본값: apache2-foreground)
exec "$@"
