<?php
// =============================================================
//  X-mas Album - 업로드 처리
//  ★ 의도된 취약점: 느슨한 화이트리스트 확장자 검증
// =============================================================

$UPLOAD_DIR = __DIR__ . '/uploads';

// 허용 확장자 화이트리스트 (jpg / jpeg / png 만)
$ALLOWED = ['jpg', 'jpeg', 'png'];

function render($ok, $title, $message, $extra = '') {
    $cls = $ok ? 'ok' : 'err';
    $icon = $ok ? '✅' : '❌';
    echo <<<HTML
<!DOCTYPE html>
<html lang="ko">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>🎄 업로드 결과</title>
<link rel="stylesheet" href="css/style.css">
</head>
<body>
<div class="snow" aria-hidden="true"></div>
<div class="container">
  <div class="card result {$cls}">
    <h2>{$icon} {$title}</h2>
    <p>{$message}</p>
    {$extra}
    <div class="actions">
      <a class="btn btn-ghost" href="index.php">← 다시 올리기</a>
      <a class="btn" href="gallery.php">갤러리 보기</a>
    </div>
  </div>
</div>
</body>
</html>
HTML;
    exit;
}

// POST 및 업로드 확인
if ($_SERVER['REQUEST_METHOD'] !== 'POST' || !isset($_FILES['photo'])) {
    render(false, '잘못된 접근', '업로드할 파일이 없습니다.');
}

$file = $_FILES['photo'];

if ($file['error'] !== UPLOAD_ERR_OK) {
    render(false, '업로드 실패', '파일 전송 중 오류가 발생했습니다. (code: ' . (int)$file['error'] . ')');
}

// 원본 파일명 (경로 조작 방지를 위해 basename 만 사용)
$originalName = basename($file['name']);

// -------------------------------------------------------------
// [취약점] "마지막 확장자" 하나만 떼어 화이트리스트를 검사한다.
//   pathinfo 는 가장 마지막 . 뒤쪽만 확장자로 본다.
//   예) shell.php.png  ->  extension === "png"  ->  검사 통과!
//   (중간에 낀 .php 는 전혀 확인하지 않는다.)
// -------------------------------------------------------------
$ext = strtolower(pathinfo($originalName, PATHINFO_EXTENSION));

if (!in_array($ext, $ALLOWED, true)) {
    render(false, '허용되지 않은 확장자',
        "오직 jpg, png 사진만 올릴 수 있습니다. (받은 확장자: <code>" . htmlspecialchars($ext) . "</code>)");
}

// Content-Type 은 검사하지 않는다 (난이도 하향, 의도된 설계).

// 저장: 원본 파일명을 그대로 유지한다.
//  -> shell.php.png 같은 이름이 보존되어 업로드 디렉토리에 저장된다.
$dest = $UPLOAD_DIR . '/' . $originalName;

// 동일 이름 충돌 시 앞에 숫자를 붙여 회피 (확장자 체인은 그대로 유지)
if (file_exists($dest)) {
    $dest = $UPLOAD_DIR . '/' . time() . '_' . $originalName;
    $originalName = basename($dest);
}

if (!move_uploaded_file($file['tmp_name'], $dest)) {
    render(false, '저장 실패', '서버에 파일을 저장하지 못했습니다.');
}

// 업로드된 파일 경로 노출 (갤러리/직접 접근 가능)
$webPath = 'uploads/' . rawurlencode($originalName);
$safeName = htmlspecialchars($originalName);
$extra = "<p class=\"path\">저장 위치: <a href=\"{$webPath}\"><code>{$webPath}</code></a></p>";

render(true, '업로드 완료!', "<strong>{$safeName}</strong> 사진이 앨범에 추가되었습니다. 🎄", $extra);
