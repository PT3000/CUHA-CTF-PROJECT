<?php
// X-mas Album - 메인 페이지
// 업로드 폼을 보여준다. (jpg/png 만 올릴 수 있다고 안내)
?>
<!DOCTYPE html>
<html lang="ko">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>🎄 X-mas Album</title>
    <link rel="stylesheet" href="css/style.css">
</head>
<body>
    <!-- 눈 내리는 효과 -->
    <div class="snow" aria-hidden="true"></div>

    <div class="container">
        <header class="hero">
            <h1>🎄 X-mas Album</h1>
            <p class="subtitle">올해의 크리스마스 추억을 업로드하고 앨범으로 간직하세요 🎁</p>
        </header>

        <section class="card">
            <h2>📷 사진 업로드</h2>
            <p class="hint">오직 <strong>jpg, png</strong> 확장자를 가진 사진만 올릴 수 있습니다.</p>

            <form class="upload-form" action="upload.php" method="post" enctype="multipart/form-data">
                <label class="file-drop">
                    <input type="file" name="photo" accept=".jpg,.jpeg,.png" required>
                    <span>여기를 눌러 사진을 선택하세요</span>
                </label>
                <button type="submit" class="btn">앨범에 올리기</button>
            </form>
        </section>

        <div class="actions">
            <a class="btn btn-ghost" href="gallery.php">갤러리 보러가기</a>
        </div>

    </div>
</body>
</html>
