<?php
// =============================================================
//  X-mas Album - 갤러리
//  업로드된 사진을 썸네일로 보여주고, 실제 저장 경로를 노출한다.
//  (경로를 통해 업로드 파일에 직접 접근 가능 -> 웹쉘 트리거에 사용)
// =============================================================

$UPLOAD_DIR = __DIR__ . '/uploads';
$WEB_DIR    = 'uploads';

// 갤러리에 썸네일로 표시할 이미지 확장자
$IMAGE_EXT = ['jpg', 'jpeg', 'png', 'gif'];

$files = [];
if (is_dir($UPLOAD_DIR)) {
    foreach (scandir($UPLOAD_DIR) as $f) {
        if ($f === '.' || $f === '..' || $f === '.gitkeep') {
            continue;
        }
        if (is_file($UPLOAD_DIR . '/' . $f)) {
            $files[] = $f;
        }
    }
}
// 최신 업로드가 위로 오도록
$files = array_reverse($files);
?>
<!DOCTYPE html>
<html lang="ko">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>X-mas Album - 갤러리</title>
    <link rel="stylesheet" href="css/style.css">
</head>
<body>
    <div class="snow" aria-hidden="true"></div>

    <div class="container">
        <header class="hero">
            <h1>갤러리</h1>
            <p class="subtitle">우리가 함께 만든 크리스마스 앨범</p>
        </header>

        <?php if (empty($files)): ?>
            <div class="card">
                <p>아직 업로드된 사진이 없어요. 첫 번째 추억을 올려보세요! 🎄</p>
            </div>
        <?php else: ?>
            <section class="grid">
                <?php foreach ($files as $f):
                    $webPath = $WEB_DIR . '/' . rawurlencode($f);
                    $ext = strtolower(pathinfo($f, PATHINFO_EXTENSION));
                    $isImage = in_array($ext, $IMAGE_EXT, true);
                    $safeName = htmlspecialchars($f);
                ?>
                    <figure class="thumb">
                        <a href="<?= $webPath ?>">
                            <?php if ($isImage): ?>
                                <img src="<?= $webPath ?>" alt="<?= $safeName ?>" loading="lazy">
                            <?php else: ?>
                                <div class="noimg">📄</div>
                            <?php endif; ?>
                        </a>
                        <!-- 업로드된 파일의 실제 경로를 그대로 노출한다 -->
                        <figcaption>
                            <a href="<?= $webPath ?>"><code><?= $WEB_DIR . '/' . $safeName ?></code></a>
                        </figcaption>
                    </figure>
                <?php endforeach; ?>
            </section>
        <?php endif; ?>

        <div class="actions">
            <a class="btn btn-ghost" href="index.php">← 메인으로</a>
        </div>
    </div>
</body>
</html>
