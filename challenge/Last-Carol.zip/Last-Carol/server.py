import hashlib
import hmac
import json
import os
from functools import partial
from http import HTTPStatus
from http.server import SimpleHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path


FLAG_HASH = "578e0aac0a542dec67104f260ce3e80669b2d262ee3d94cfcd19e26f332dc8f3"
MAX_FLAG_BYTES = 4096
PUBLIC_DIRECTORY = Path(__file__).resolve().parent / "public"


class ChallengeHandler(SimpleHTTPRequestHandler):
    def setup(self):
        self.request.settimeout(10)
        super().setup()

    def do_POST(self):
        if self.path != "/check":
            self.send_error(HTTPStatus.NOT_FOUND)
            return

        try:
            length = int(self.headers.get("Content-Length", ""))
        except ValueError:
            self.send_error(HTTPStatus.BAD_REQUEST)
            return
        if length < 0 or length > MAX_FLAG_BYTES:
            self.send_error(HTTPStatus.REQUEST_ENTITY_TOO_LARGE)
            return

        value = self.rfile.read(length)
        if len(value) != length:
            self.send_error(HTTPStatus.BAD_REQUEST)
            return

        digest = hashlib.sha256(value).hexdigest()
        response = json.dumps({"correct": hmac.compare_digest(digest, FLAG_HASH)}).encode()
        self.send_response(HTTPStatus.OK)
        self.send_header("Content-Type", "application/json")
        self.send_header("Content-Length", str(len(response)))
        self.send_header("Cache-Control", "no-store")
        self.end_headers()
        self.wfile.write(response)


if __name__ == "__main__":
    handler = partial(ChallengeHandler, directory=PUBLIC_DIRECTORY)
    with ThreadingHTTPServer(("0.0.0.0", int(os.getenv("PORT", "8010"))), handler) as server:
        server.serve_forever()
