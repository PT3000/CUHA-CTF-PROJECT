# 마지막 캐럴이 울린 곳

```bash
docker compose up -d --build
```

같은 컴퓨터에서 [http://localhost:8010](http://localhost:8010)을 엽니다. 같은 네트워크의 다른 컴퓨터에서는 `http://서버IP:8010`으로 접속합니다.

Docker Compose 없이 실행할 수도 있습니다.

```bash
docker build -t last-carol-osint .
docker run -d --name last-carol-osint -p 8010:8010 last-carol-osint
```

Compose로 실행한 경우 중지할 때는 `docker compose down`을 사용합니다.
