const form = document.querySelector('form');
const result = document.getElementById('result');

const maxScore = 100;
const scoreLabel = document.getElementById('score');
const hints = [...document.querySelectorAll('[data-hint-cost]')];
const revealedHints = new Set();
const storageKey = 'carol-osint-hints-v1';
let solved = false;

try {
  const stored = JSON.parse(sessionStorage.getItem(storageKey) || '[]');
  if (Array.isArray(stored)) {
    for (const hint of hints) {
      const id = hint.getAttribute('aria-controls');
      if (stored.includes(id)) revealedHints.add(id);
    }
  }
} catch {
}

function score() {
  return hints.reduce((points, hint) => {
    return revealedHints.has(hint.getAttribute('aria-controls'))
      ? points - Number(hint.dataset.hintCost)
      : points;
  }, maxScore);
}

function renderScore() {
  scoreLabel.textContent = '현재 점수 ' + score() + '점';
}

function reveal(hint) {
  const id = hint.getAttribute('aria-controls');
  document.getElementById(id).hidden = false;
  hint.setAttribute('aria-expanded', 'true');
  hint.disabled = true;
  hint.textContent = hint.textContent.replace(/힌트 보기.*$/, '힌트 공개됨');
}

for (const hint of hints) {
  const id = hint.getAttribute('aria-controls');
  if (revealedHints.has(id)) reveal(hint);

  hint.addEventListener('click', () => {
    if (solved || revealedHints.has(id)) return;
    revealedHints.add(id);
    reveal(hint);
    renderScore();

    try {
      sessionStorage.setItem(storageKey, JSON.stringify([...revealedHints]));
    } catch {
    }
  });
}

renderScore();

form.addEventListener('submit', async event => {
  event.preventDefault();
  if (solved) return;

  const button = form.querySelector('button');
  button.disabled = true;
  try {
    const value = document.getElementById('flag').value.trim();
    const response = await fetch('/check', {
      method: 'POST',
      headers: { 'Content-Type': 'text/plain; charset=utf-8' },
      body: value,
    });

    if (!response.ok) throw new Error('Flag check failed');
    const { correct } = await response.json();
    result.className = correct ? 'ok' : 'wrong';
    result.textContent = correct
      ? '정답입니다! 최종 점수 ' + score() + '점'
      : '틀렸습니다. 무대 코드, 공연 ID, 현장 시각을 다시 확인하세요.';

    if (correct) {
      solved = true;
      for (const hint of hints) hint.disabled = true;
    }
  } catch {
    result.className = 'wrong';
    result.textContent = '채점에 실패했습니다. 잠시 후 다시 시도하세요.';
  } finally {
    button.disabled = solved;
  }
});
